﻿namespace WebAPITranflangar.Controllers
{
    using System.Globalization;
    using Microsoft.AspNetCore.Mvc;
    using WebAPITranflangar.Models;
    using RouteAttribute = Microsoft.AspNetCore.Mvc.RouteAttribute;
    using ActionNameAttribute = Microsoft.AspNetCore.Mvc.ActionNameAttribute;
    using Newtonsoft.Json.Linq;
    using System.Reflection;

    [ApiController]
    [Route("api/Order")]
    public class OrderController
    {
        /// <summary>
        /// Contains the logger.
        /// </summary>
        readonly ILogger log;

        /// <summary>
        /// Contains the crmHelper class.
        /// </summary>
        readonly CRMHelper crmHelper = new();

        /// <summary>
        /// Contains the Ilogger.
        /// </summary>
        private readonly ILogger<OrderController> _logger;

        /// <summary>
        /// COntains the Ilogger class.
        /// </summary>
        /// <param name="logger"></param>
        public OrderController(ILogger<OrderController> logger)
        {
            _logger = logger;
        }

        /// <summary>
        /// Enquiry search WebApi Method.
        /// </summary>
        /// <param name="customer">Contains the JSON Payload</param>
        /// <returns>returns a string of entity object.</returns>
        /// <exception cref="Exception"></exception>
        /// 

        [HttpPost("SearchOrder")]
        [ActionName(nameof(SearchOrder))]
        public async Task<ResultObject> SearchOrder([FromBody] Models.Customer customervalue)
        {
            var r = new ResultObject();
            var baseAPIUrl = await crmHelper.RetrieveEnvironmentValue(customervalue.EnvironmentValue, "OpenOrderSearch",log);
            try
            {
                var response = new HttpResponseMessage();
                var opernOrderSearchAPI = baseAPIUrl.Replace("{PH.CUSTOMERID}", customervalue.CustomerId);
                response = await crmHelper.RetrieveMultiple(opernOrderSearchAPI, customervalue.EnvironmentValue, log);
                if (response != null)
                {
                    r.code = Convert.ToInt16(response.StatusCode);
                    r.message = "response recieved";
                    r.data = response.Content.ReadAsStringAsync().Result;
                }
                else
                {
                    //return ducOpenOrderSearch.ToString();
                }

                return r;
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in openOrderSearch API {0}", ex.Message));
            }
        }


        [HttpPost("OpenOrderDetailsView")]
        [ActionName(nameof(OpenOrderDetailsView))]
        public async Task<ResultObject> OpenOrderDetailsView([FromBody] PurchaseHistory purchaseHistory)
        {
            var r = new ResultObject();
            var baseAPIUrl = await crmHelper.RetrieveEnvironmentValue(purchaseHistory.EnvironmentValue, "OpenOrderDetailsView",log);
            try
            {
                var response = new HttpResponseMessage();
                var opernOrderDetailsAPI = baseAPIUrl.Replace("{PH.PURCHASEHISTORYID}", purchaseHistory.PurchaseHistoryId);
                response = await crmHelper.RetrieveMultiple(opernOrderDetailsAPI, purchaseHistory.EnvironmentValue, log);
                if (response != null)
                {
                    r.code = Convert.ToInt16(response.StatusCode);
                    r.message = "response recieved";
                    r.data = response.Content.ReadAsStringAsync().Result;
                }
                else
                {
                    //return ducOpenOrderDetailsView.ToString();
                }

                return r;
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in openOrderDetailsView API {0}", ex.Message));
            }
        }


        [HttpPost("GetOrderByInvoiceNo")]
        [ActionName(nameof(GetOrderByInvoiceNo))]
        public async Task<ResultObject> GetOrderByInvoiceNo([FromBody] InvoiceNumber invoice)
        {
            var r = new ResultObject();
            var baseAPIUrl = await crmHelper.RetrieveEnvironmentValue(invoice.EnvironmentValue, "diyar_GetOrderByInvoiceNo", log);
            try
            {
                var response = new HttpResponseMessage();
                var opernOrderDetailsAPI = baseAPIUrl.Replace("{OD.INVOICE}", invoice.InvioiceNo);
                response = await crmHelper.RetrieveMultiple(opernOrderDetailsAPI, invoice.EnvironmentValue, log);
                if (response != null)
                {
                    r.code = Convert.ToInt16(response.StatusCode);
                    r.message = "response recieved";
                    r.data = response.Content.ReadAsStringAsync().Result;
                }
                else
                {
                    //return ducOpenOrderDetailsView.ToString();
                }

                return r;
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in openOrderDetailsView API {0}", ex.Message));
            }
        }


    }
}
