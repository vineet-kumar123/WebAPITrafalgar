﻿namespace WebAPITranflangar.Controllers
{
    using System.Globalization;
    using Microsoft.AspNetCore.Mvc;
    using WebAPITranflangar.Models;
    using RouteAttribute = Microsoft.AspNetCore.Mvc.RouteAttribute;
    using ActionNameAttribute = Microsoft.AspNetCore.Mvc.ActionNameAttribute;
    using Newtonsoft.Json.Linq;
    using System.Reflection;

    [ApiController]
    [Route("api/Purchase")]
    public class PurchaseController
    {
        /// <summary>
        /// Contains the logger.
        /// </summary>
        readonly ILogger log;

        /// <summary>
        /// Contains the crmHelper class.
        /// </summary>
        readonly CRMHelper crmHelper = new();

        /// <summary>
        /// Contains the Ilogger.
        /// </summary>
        private readonly ILogger<PurchaseController> _logger;

        /// <summary>
        /// COntains the Ilogger class.
        /// </summary>
        /// <param name="logger"></param>
        public PurchaseController(ILogger<PurchaseController> logger)
        {
            _logger = logger;
        }


        /// <summary>
        /// Purchase Search Method.
        /// </summary>
        /// <param name="customer">Contains the JSON Payload</param>
        /// <returns>returns a string of entity object.</returns>
        /// <exception cref="Exception"></exception>
        [HttpPost("SearchPurchases")]
        [ActionName(nameof(SearchPurchases))]
        public async Task<ResultObject> SearchPurchases([FromBody] Models.Customer customervalue)
        {
            var r = new ResultObject();
            var baseAPIUrl = await crmHelper.RetrieveEnvironmentValue(customervalue.EnvironmentValue, "PurchaseSearch",log);
            try
            {
                var response = new HttpResponseMessage();
                var purchaseSearchAPI = baseAPIUrl.Replace("{CV.CUSTOMERID}", customervalue.CustomerId);
                response = await crmHelper.RetrieveMultiple(purchaseSearchAPI, customervalue.EnvironmentValue, log);
                if (response != null)
                {
                    r.code = Convert.ToInt16(response.StatusCode);
                    r.message = "response recieved";
                    r.data = response.Content.ReadAsStringAsync().Result;
                }
                else
                {
                    //return ducPurchaseSearch.ToString();
                }
                return r;
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in PurchseSearch API {0}", ex.Message));
            }
        }

        /// <summary>
        /// Purchase Detail View Method.
        /// </summary>
        /// <param name="customer">Contains the JSON Payload</param>
        /// <returns>returns a string of entity object.</returns>
        /// <exception cref="Exception"></exception>
        [HttpPost("GetPurchaseById")]
        [ActionName(nameof(GetPurchaseById))]
        public async Task<ResultObject> GetPurchaseById([FromBody] PurchaseHistory purchasehistory)
        {
            var r = new ResultObject();
            var baseAPIUrl = await crmHelper.RetrieveEnvironmentValue(purchasehistory.EnvironmentValue, "PurchaseDetailView", log);
            try
            {
                var response = new HttpResponseMessage();
                var purchaseDetailViewAPI = baseAPIUrl.Replace("{PR.PURCHASEHISTORYID}", purchasehistory.PurchaseHistoryId);
                response = await crmHelper.RetrieveMultiple(purchaseDetailViewAPI, purchasehistory.EnvironmentValue, log);
                if (response != null)
                {
                    r.code = Convert.ToInt16(response.StatusCode);
                    r.message = "response recieved";
                    r.data = response.Content.ReadAsStringAsync().Result;
                }
                else
                {
                    //return ducPurhcaseDetailView.ToString();
                }

                return r;
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in purchaseDetailView API {0}", ex.Message));
            }
        }


        [HttpPost("GetPurchaseByOrderNo")]
        [ActionName(nameof(GetPurchaseByOrderNo))]
        public async Task<ResultObject> GetPurchaseByOrderNo([FromBody] Order orderNo)
        {
            var r = new ResultObject();
            var baseAPIUrl = await crmHelper.RetrieveEnvironmentValue(orderNo.EnvironmentValue, "diyar_GetPurchaseByOrderNo", log);
            try
            {
                var response = new HttpResponseMessage();
                var purchaseDetailViewAPI = baseAPIUrl.Replace("{OD.NO}", orderNo.OrrderNo);
                response = await crmHelper.RetrieveMultiple(purchaseDetailViewAPI, orderNo.EnvironmentValue, log);
                if (response != null)
                {
                    r.code = Convert.ToInt16(response.StatusCode);
                    r.message = "response recieved";
                    r.data = response.Content.ReadAsStringAsync().Result;
                }
                else
                {
                    //return ducPurhcaseDetailView.ToString();
                }

                return r;
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in purchaseDetailView API {0}", ex.Message));
            }
        }


    }
}
