﻿namespace WebAPITranflangar.Controllers
{
    using System.Globalization;
    using Microsoft.AspNetCore.Mvc;
    using WebAPITranflangar.Models;
    using RouteAttribute = Microsoft.AspNetCore.Mvc.RouteAttribute;
    using ActionNameAttribute = Microsoft.AspNetCore.Mvc.ActionNameAttribute;
    using Newtonsoft.Json.Linq;
    using System.Reflection;


    [ApiController]
    [Route("api/ForgotPassword")]
    public class ForgotPasswordController
    {
        /// <summary>
        /// Contains the logger.
        /// </summary>
        readonly ILogger log;

        /// <summary>
        /// Contains the crmHelper class.
        /// </summary>
        readonly CRMHelper crmHelper = new();

        /// <summary>
        /// Contains the Ilogger.
        /// </summary>
        private readonly ILogger<ForgotPasswordController> _logger;

        /// <summary>
        /// COntains the Ilogger class.
        /// </summary>
        /// <param name="logger"></param>
        public ForgotPasswordController(ILogger<ForgotPasswordController> logger)
        {
            _logger = logger;
        }



        [HttpPost("GetContactAndRegistrationByMobile")]
        [ActionName(nameof(GetContactAndRegistrationByMobile))]
        public async Task<ResultObject> GetContactAndRegistrationByMobile([FromBody] RegistrationContactMobile mobile)
        {
            var r = new ResultObject();
            var baseAPIUrl = await crmHelper.RetrieveEnvironmentValue(mobile.EnvironmentValue, "diyar_GetRegistrationAndContactByMobile", log);
            try
            {
                var response = new HttpResponseMessage();
                var wishListAPI = baseAPIUrl.Replace("{CN.MOBILE}", mobile.mobile);
                response = await crmHelper.RetrieveMultiple(wishListAPI, mobile.EnvironmentValue, log);
                if (response != null)
                {
                    r.code = Convert.ToInt16(response.StatusCode);
                    r.message = "response recieved";
                    r.data = response.Content.ReadAsStringAsync().Result;
                }
                else
                {
                    //return ducCustomerWishList.ToString();
                }

                return r;
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in wishlist API {0}", ex.Message));
            }

        }


        [HttpPost("GetContactAndRegistrationByEmail")]
        [ActionName(nameof(GetContactAndRegistrationByEmail))]
        public async Task<ResultObject?> GetContactAndRegistrationByEmail([FromBody] RegistrationContactEmail Email)
        {
            var baseAPIUrl = await crmHelper.RetrieveEnvironmentValue(Email.EnvironmentValue, "diyar_GetRegistrationAndContactByEmail",log);
            try
            {
                var response = new HttpResponseMessage();
                var r = new ResultObject();
                var RegistrationAPI = baseAPIUrl.Replace("{CN.EMAIL}", Email.Email);
                response = await crmHelper.RetrieveMultiple(RegistrationAPI, Email.EnvironmentValue, log);
                if (response != null)
                {
                    r.code = Convert.ToInt16(response.StatusCode);
                    r.message = "response recieved";
                    r.data = response.Content.ReadAsStringAsync().Result;
                }
                else
                {
                    //return GetRegistrationAndContactByEmail.ToString();
                }

                return r;
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in Contact API {0}", ex.Message));
            }
        }


        [HttpPost("ChangePassword")]
        [ActionName(nameof(ChangePassword))]
        public async Task<string?> ChangePassword([FromBody] ChangePassword password)
        {
            try
            {
                JObject PasswordUpdate = new()
                {
                 
                    ["duc_registrationid"] = !string.IsNullOrEmpty(password.duc_registraionId) ? password.duc_registraionId : null,
 
                    ["duc_currentpassword "] = !string.IsNullOrEmpty(password.duc_currentpassword) ? password.duc_currentpassword : null,
  
                };
                if (string.IsNullOrEmpty(password.duc_registraionId))
                {
                    return "registration id is mandatory";
                }
                await crmHelper.UpdateEntityRecordInCRM("duc_registrations", PasswordUpdate["duc_registrationid"].ToString(), PasswordUpdate, password.EnvironmentValue, log);

            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in GetCustomerByMobileAndFirstName API {0}", ex.Message));
            }
            return string.Empty;

        }

        [HttpPost("SendResetPasswordLink")]
        [ActionName(nameof(SendResetPasswordLink))]
        public async Task<string?> SendResetPasswordLink([FromBody] ResetPassword password)
        {
            try
            {
                JObject ResetPassword = new()
                {

                    ["duc_registrationid"] = !string.IsNullOrEmpty(password.duc_registraionId) ? password.duc_registraionId : null,

                    ["duc_link "] = !string.IsNullOrEmpty(password.duc_link) ? password.duc_link : null,

                    ["duc_sendresetpasswordlink"] = !string.IsNullOrEmpty(password.duc_sendresetpasswordlink.ToString()) ? password.duc_sendresetpasswordlink : null,

                };
                if (string.IsNullOrEmpty(password.duc_registraionId))
                {
                    return "registration id is mandatory";
                }
                await crmHelper.UpdateEntityRecordInCRM("duc_registrations", ResetPassword["duc_registrationid"].ToString(), ResetPassword, password.EnvironmentValue, log);

            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in GetCustomerByMobileAndFirstName API {0}", ex.Message));
            }
            return string.Empty;

        }


        [HttpPost("ResetPasswordKeyCheck")]
        [ActionName(nameof(ResetPasswordKeyCheck))]
        public async Task<string?> ResetPasswordKeyCheck([FromBody] PasswordKeyCheck password)
        {
            try
            {
                JObject PasswordKeyCheck = new()
                {

                    ["duc_registrationid"] = !string.IsNullOrEmpty(password.duc_registraionId) ? password.duc_registraionId : null,

                    ["duc_forgotpasswordkeyfromsource "] = !string.IsNullOrEmpty(password.duc_forgotpasswordkeyfromsource) ? password.duc_forgotpasswordkeyfromsource : null,

                    
                };
                if (string.IsNullOrEmpty(password.duc_registraionId))
                {
                    return "registration id is mandatory";
                }
                await crmHelper.UpdateEntityRecordInCRM("duc_registrations", PasswordKeyCheck["duc_registrationid"].ToString(), PasswordKeyCheck, password.EnvironmentValue, log);

            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in GetCustomerByMobileAndFirstName API {0}", ex.Message));
            }
            return string.Empty;

        }


    }
}
