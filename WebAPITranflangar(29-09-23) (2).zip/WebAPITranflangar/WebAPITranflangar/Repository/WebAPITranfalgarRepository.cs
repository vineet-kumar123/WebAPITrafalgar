﻿using WebAPITranflangar.Interface;
using WebAPITranflangar.Models;

namespace WebAPITranflangar.Repository
{
    public class WebAPITranfalgarRepository : IWrapperTrafalgarCRM
    {
        List<WrapperTrafalgarCRM> IWrapperTrafalgarCRM.GetAllMember()
        {
            throw new NotImplementedException();
        }

        WrapperTrafalgarCRM IWrapperTrafalgarCRM.GetMember(int id)
        {
            throw new NotImplementedException();
        }
    }
}
