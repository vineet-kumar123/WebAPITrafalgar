﻿namespace WebAPITranflangar.Models
{
    using System.Net;
    using System.Net.Http.Headers;
    using System.Text.RegularExpressions;
    using Microsoft.IdentityModel.Clients.ActiveDirectory;
    using Newtonsoft.Json.Linq;
    using WebAPITranflangar.Interface;
    using static WebAPITranflangar.Models.HttpClientHelper;

    /// <summary>
    /// CRM helper class.
    /// </summary>
    public class CRMHelper : ICRMHelper
    {
        /// <summary>
        /// Property for the Http Client.
        /// </summary>
        private HttpClient? httpClient = null;

        /// <summary>
        /// Property for formatted Value headers.
        /// </summary>
        private Dictionary<string, List<string>>? formattedValueHeaders;

        /// <summary>
        /// Property of the accessToken.
        /// </summary>
        private string accessToken = string.Empty;

        /// <summary>
        /// Class for Retrieve Access Token. 
        /// </summary>
        /// <param name="environmentValue">Contains the environemental value.</param>
        /// <returns>Returns a string Value.</returns>
        public async Task<string> RetrieveAccessToken(string environmentValue)
        {
            this.formattedValueHeaders = new Dictionary<string, List<string>>
            {
                {
                    "Prefer", new List<string>
                    {
                        "odata.include-annotations=\"*\""
                    }
                }
            };

            Dictionary<string, string> appConfigSettings = await RetriveAppSettings(environmentValue);


            string clientId = appConfigSettings["client_id"];  // Your Azure AD Application ID
            string clientSecret = appConfigSettings["client_secret"];// Client secret generated in your App
            string authority = appConfigSettings["authority"];  // Azure AD App Tenant ID
            string resourceUrl = appConfigSettings["CRMUrl"]; /// Your Dynamics 365 Organization URL

            var credentials = new ClientCredential(clientId, clientSecret);
            var authContext = new AuthenticationContext(authority);
            var result = await authContext.AcquireTokenAsync(resourceUrl, credentials);
            return result.AccessToken;
        }

        /// <summary>
        /// Class for Retrieve method.
        /// </summary>
        /// <param name="oDataQuery">Contains teh oDataQuery.</param>
        /// <param name="environmentValue">Contains the environmental Value.</param>
        /// <param name="log">Contains the log.</param>
        /// <returns>Returns JObject.</returns>
        /// <exception cref="Exception"></exception>
        public async Task<JObject> Retrieve(string oDataQuery, string environmentValue, ILogger log)
        {
            try
            {
                httpClient = new HttpClientHelper(environmentValue).GetHttpClient(environmentValue);
                this.accessToken = await RetrieveAccessToken(environmentValue);
                List<JObject> entities = new List<JObject>();

                using (var request = new HttpRequestMessage(HttpMethod.Get, oDataQuery))
                {
                    foreach (KeyValuePair<string, List<string>> header in this.formattedValueHeaders)
                    {
                        if (!request.Headers.Contains(header.Key))
                            request.Headers.Add(header.Key, header.Value);
                    }

                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                    this.httpClient.DefaultRequestHeaders.Authorization = new
                        System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", this.accessToken);
                    try
                    {
                        var response = await this.httpClient.SendAsync(request, HttpCompletionOption.ResponseHeadersRead);

                        if (response.StatusCode == HttpStatusCode.OK)
                        {
                            if (response.Content != null)
                            {
                                JToken result = JToken.Parse(response.Content.ReadAsStringAsync().Result);
                                if (result != null && result["value"] != null && result["value"].HasValues)
                                {
                                    entities.AddRange(((JArray)result["value"]).ToList().Select(i => (JObject)i));

                                }
                            }
                        }
                        return entities.First();
                    }
                    catch (Exception ex)
                    {
                        throw new Exception(ex.Message);
                    }
                }




            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
       
        /// <summary>
        /// Class for the RetrieveMultiple.
        /// </summary>
        /// <param name="oDataQuery">Contains teh oDataQuery.</param>
        /// <param name="environmentValue">Contains the environemental Value.</param>
        /// <param name="log">Contains the logger.</param>
        /// <returns>Returns a list of JObject.</returns>
        /// <exception cref="Exception"></exception>
        public async Task<HttpResponseMessage> RetrieveMultiple(string oDataQuery, string environmentValue, ILogger log)
        {
            try
            {
                httpClient = new HttpClientHelper(environmentValue).GetHttpClient(environmentValue);
                this.accessToken = await RetrieveAccessToken(environmentValue);

                List<JObject> entities = new List<JObject>();

                using (var request = new HttpRequestMessage(HttpMethod.Get, oDataQuery))
                {
                    foreach (KeyValuePair<string, List<string>> header in this.formattedValueHeaders)
                    {
                        if (!request.Headers.Contains(header.Key))
                            request.Headers.Add(header.Key, header.Value);
                    }

                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                    this.httpClient.DefaultRequestHeaders.Authorization = new
                        System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", this.accessToken);
                    try
                    {
                        var response = await this.httpClient.SendAsync(request, HttpCompletionOption.ResponseHeadersRead);
                        return response ;
                      /* if (response.StatusCode == HttpStatusCode.OK)
                        {
                            if (response.Content != null)
                            {
                                JToken result = JToken.Parse(response.Content.ReadAsStringAsync().Result);
                                if (result != null && result["value"] != null && result["value"].HasValues)
                                {
                                    entities.AddRange(((JArray)result["value"]).ToList().Select(i => (JObject)i));
                                    oDataQuery = string.Format("{0}", result["@odata.nextlink"]);

                                    if (!string.IsNullOrEmpty(oDataQuery))
                                    {
                                        entities.AddRange((IEnumerable<JObject>)await this.RetrieveMultiple(oDataQuery, environmentValue, log));
                                    }
                                }
                            }
                        }*/

                    }
                    catch (Exception ex)
                    {
                        throw new Exception(ex.Message);
                    }
                    //return entities;
                }
            }
            catch(Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        
        /// <summary>
        /// Class for Create Entity Record in CRM.
        /// </summary>
        /// <param name="entity">Contains the entity Object.</param>
        /// <param name="entityObj">Contains the Entity JObject.</param>
        /// <param name="environmentValue">Contains the environmental Value.</param>
        /// <param name="log">Contains the logger.</param>
        /// <returns>Returns a Guid.</returns>
        public async Task<Guid> CreateEntityRecordInCRM(string entity, JObject entityObj, string environmentValue, ILogger log)
        {
            httpClient = new HttpClientHelper(environmentValue).GetHttpClient(environmentValue);
            JToken contactEntity;
            Guid retrievedGuid = Guid.Empty;
            Regex rx = new Regex(@"\(([^)]+)\)");
            if ((!string.IsNullOrEmpty(entity)&& entityObj !=null))
            {
                contactEntity = await this.PostCreateAsync(entity, entityObj, environmentValue);
                if (contactEntity != null)
                {
                    Match match = rx.Match(contactEntity.ToString());
                    retrievedGuid = new Guid(match.Value);
                    return retrievedGuid;
                }
            }
            return retrievedGuid;
        }
        
        /// <summary>
        /// Class for Post Create Async.
        /// </summary>
        /// <param name="entityName">Contains the entityName.</param>
        /// <param name="entityObj">Contains the entity JObject.</param>
        /// <param name="environmentValue">Contains the environmental Value.</param>
        /// <returns>Contains Uri.</returns>
        public async Task<Uri> PostCreateAsync(string entityName, object entityObj, string environmentValue)
        {
            accessToken = await RetrieveAccessToken(environmentValue);
            using (var request = new HttpRequestMessage(HttpMethod.Post, entityName))
            {
                foreach (KeyValuePair<string, List<string>> header in this.formattedValueHeaders)
                {
                    if (!request.Headers.Contains(header.Key))
                        request.Headers.Add(header.Key, header.Value);
                }

                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

                request.Content = new StringContent(JObject.FromObject(entityObj).ToString());
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", this.accessToken);
                request.Content.Headers.ContentType = MediaTypeHeaderValue.Parse("application/json");
                using (HttpResponseMessage respone = await SendAsync(request))
                {
                    return new Uri(respone.Headers.GetValues("OData-EntityId").FirstOrDefault());
                }
            }
        }
        
        /// <summary>
        /// Class for the Send Async. 
        /// </summary>
        /// <param name="request">Contains the Http Request Message.</param>
        /// <param name="completionOption">Contains the http Compleetion option.</param>
        /// <returns>Returns a Http Response Message.</returns>
        private async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, HttpCompletionOption completionOption = HttpCompletionOption.ResponseContentRead)
        {
            HttpResponseMessage? response = null;
            try
            {
                response = await this.httpClient.SendAsync(request, completionOption);
            }
            catch (Exception ex)
            {

            }
            return response;
        }

        /// <summary>
        /// Contains the Retrieve App Settings.
        /// </summary>
        /// <param name="environment">Contains the environmental value.</param>
        /// <returns>returns a dictionary value.</returns>
        /// 

        public async Task<string> RetrieveEnvironmentValue(string environmentValue, string ODataAPIName, ILogger log)
        {
            string environmentalDefiniation = string.Empty;
            var builder = WebApplication.CreateBuilder();
            if (environmentValue == "staging")
            {
                var section = builder.Configuration.GetSection($"app_config_staging");
                environmentalDefiniation = section.GetValue(typeof(string), "environmentalDefiniationUrl").ToString();
            }
            else if (environmentValue == "prod")
            {
                var section = builder.Configuration.GetSection($"app_config_prod");
                environmentalDefiniation = section.GetValue(typeof(string), "environmentalDefiniationUrl").ToString();
            }
            string environmentalUrl = environmentalDefiniation.Replace("{ODataAPIName}", ODataAPIName);
            JObject environmentVariable = await Retrieve(environmentalUrl, environmentValue,log);
            return environmentVariable["defaultvalue"].ToString();
        }

        public async static Task<Dictionary<string, string>> RetriveAppSettings(string environment)
        {

            Dictionary<string, string> appSettings = new Dictionary<string, string>();
            var builder = WebApplication.CreateBuilder();
            //get the list of strings as an object.
            if (environment == "staging")
            {
                var section = builder.Configuration.GetSection($"app_config_staging");
                appSettings.Add("CRMUrl", section.GetValue(typeof(string), "CRMUrl").ToString());
                appSettings.Add("client_id", section.GetValue(typeof(string), "client_id").ToString());
                appSettings.Add("client_secret", section.GetValue(typeof(string), "client_secret").ToString());
                appSettings.Add("authority", section.GetValue(typeof(string), "authority").ToString());
            }
            else if (environment =="prod")
            {
                var section = builder.Configuration.GetSection($"app_config_prod");
                appSettings.Add("CRMUrl", section.GetValue(typeof(string), "CRMUrl").ToString());
                appSettings.Add("client_id", section.GetValue(typeof(string), "client_id").ToString());
                appSettings.Add("client_secret", section.GetValue(typeof(string), "client_secret").ToString());
                appSettings.Add("authority", section.GetValue(typeof(string), "authority").ToString());
            }
            return appSettings;
        }

        public async Task UpdateEntityRecordInCRM(string entity, string recordid, JObject entityObj, string environmentValue, ILogger log)
        {
            httpClient = new HttpClientHelper(environmentValue).GetHttpClient(environmentValue);
            accessToken = await RetrieveAccessToken(environmentValue);
            using (var request = new HttpRequestMessage(HttpMethod.Patch, entity))
            {
                foreach (KeyValuePair<string, List<string>> header in this.formattedValueHeaders)
                {
                    if (!request.Headers.Contains(header.Key))
                        request.Headers.Add(header.Key, header.Value);
                }




                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                request.RequestUri = new Uri(httpClient.BaseAddress.ToString() + entity + "(" + recordid + ")");
                request.Content = new StringContent(JObject.FromObject(entityObj).ToString());
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", this.accessToken);
                request.Content.Headers.ContentType = MediaTypeHeaderValue.Parse("application/json");
                using (HttpResponseMessage respone = await SendAsync(request))
                {

                }
            }
        }

        Task<List<JObject>> ICRMHelper.RetrieveMultiple(string oDataQuery, string environmentValue, ILogger log)
        {
            throw new NotImplementedException();
        }
    }
}