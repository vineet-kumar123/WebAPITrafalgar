﻿namespace WebAPITranflangar.Controllers
{

    using System.Globalization;
    using Microsoft.AspNetCore.Mvc;
    using WebAPITranflangar.Models;
    using RouteAttribute = Microsoft.AspNetCore.Mvc.RouteAttribute;
    using ActionNameAttribute = Microsoft.AspNetCore.Mvc.ActionNameAttribute;
    using Newtonsoft.Json.Linq;
    using System.Reflection;

    [ApiController]
    [Route("api/Enquiry")]
    public class EnquiryController
    {
        /// <summary>
        /// Contains the logger.
        /// </summary>
        readonly ILogger log;

        /// <summary>
        /// Contains the crmHelper class.
        /// </summary>
        readonly CRMHelper crmHelper = new();

        /// <summary>
        /// Contains the Ilogger.
        /// </summary>
        private readonly ILogger<EnquiryController> _logger;

        /// <summary>
        /// COntains the Ilogger class.
        /// </summary>
        /// <param name="logger"></param>
        public EnquiryController(ILogger<EnquiryController> logger)
        {
            _logger = logger;
        }

        /// <summary>
        /// Enquiry search WebApi Method.
        /// </summary>
        /// <param name="customer">Contains the JSON Payload</param>
        /// <returns>returns a string of entity object.</returns>
        /// <exception cref="Exception"></exception>
        /// 


        [HttpPost("EnquirySearch")]
        [ActionName(nameof(EnquirySearch))]
        public async Task<ResultObject> EnquirySearch([FromBody] Models.Customer customer)
        {
            var r = new ResultObject();
            var baseAPIUrl = await crmHelper.RetrieveEnvironmentValue(customer.EnvironmentValue, "EnquirySearch",log);
            try
            {
                var response = new HttpResponseMessage();
                var enquirySearchAPI = baseAPIUrl.Replace("{CR.CUSTOMERID}", customer.CustomerId);
                response = await crmHelper.RetrieveMultiple(enquirySearchAPI, customer.EnvironmentValue, log);
                if (response != null)
                {
                    r.code = Convert.ToInt16(response.StatusCode);
                    r.message = "response recieved";
                    r.data = response.Content.ReadAsStringAsync().Result;
                }
                else
                {
                    //return ducEnquirySeach.ToString();

                }
                return r;
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in enqirySearch API {0}", ex.Message));
            }
        }


        [HttpPost("GetEnquiryById")]
        [ActionName(nameof(GetEnquiryById))]
        public async Task<ResultObject?> GetEnquiryById([FromBody] Incident incident)
        {
            var r = new ResultObject();
            var baseAPIUrl = await crmHelper.RetrieveEnvironmentValue(incident.EnvironmentValue, "EnquiryDetailView", log);
            try
            {
                var response = new HttpResponseMessage();
                var EnquiryDetailViewAPI = baseAPIUrl.Replace("{IN.INCIDENTID}", incident.IncidentId);
                response = await crmHelper.RetrieveMultiple(EnquiryDetailViewAPI, incident.EnvironmentValue, log);
                if (response != null)
                {

                    r.code = Convert.ToInt16(response.StatusCode);
                    r.message = "response recieved";
                    r.data = response.Content.ReadAsStringAsync().Result;
                }
                else
                {
                    //return ducEnquiryDetailView.ToString();
                }
                return r;
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in EnquiryDetailView API {0}", ex.Message));
            }
        }


        [HttpPost("AddEnquiry")]
        [ActionName(nameof(AddEnquiry))]
        public async Task<string> AddEnquiry([FromBody] AddEnquiry Enquiry)
        {
            try
            {
                JObject CaseCreate = new()
                {
                    ["customerid_contact@odata.bind"] = !string.IsNullOrEmpty(Enquiry.CustomerId_Contact) ? Enquiry.CustomerId_Contact : null,
                    ["caseorigincode"] = !string.IsNullOrEmpty(Enquiry.CaseOriginCode) ? Enquiry.CaseOriginCode : null,
                    ["title"] = !string.IsNullOrEmpty(Enquiry.title) ? Enquiry.title : null,

                    ["casetypecode"] = !string.IsNullOrEmpty(Enquiry.CaseTypeCode.ToString()) ? Enquiry.CaseTypeCode : null,
                    ["description"] = !string.IsNullOrEmpty(Enquiry.description) ? Enquiry.description : null,




                };
                var incident = await crmHelper.CreateEntityRecordInCRM("incidents", CaseCreate, Enquiry.EnvironmentValue, log);

            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in UpdateCustomer API {0}", ex.Message));
            }
            return string.Empty;

        }


        [HttpPost("AddEnquiryAttachment")]
        [ActionName(nameof(AddEnquiryAttachment))]
        public async Task<string> AddEnquiryAttachment([FromBody] EnquiryAttachment attachment)
        {
            try
            {
                JObject Annotationsattachment = new()
                {
                    ["isdocument"] = !string.IsNullOrEmpty(attachment.IsDocument.ToString()) ? attachment.IsDocument : null,
                    ["objecttypecode"] = !string.IsNullOrEmpty(attachment.objecttypecode) ? attachment.objecttypecode : null,
                    ["objectid_incident@odata.bind"] = !string.IsNullOrEmpty(attachment.objectId_incident) ? attachment.objectId_incident : null,

                    ["filename"] = !string.IsNullOrEmpty(attachment.filename) ? attachment.filename : null,
                    ["mimetype"] = !string.IsNullOrEmpty(attachment.mimetype) ? attachment.mimetype : null,
                    ["documentbody"] = !string.IsNullOrEmpty(attachment.documentBody) ? attachment.documentBody : null,




                };
                var incident = await crmHelper.CreateEntityRecordInCRM("annotations", Annotationsattachment, attachment.EnvironmentValue, log);

            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in UpdateCustomer API {0}", ex.Message));
            }
            return string.Empty;

        }

    }
}
