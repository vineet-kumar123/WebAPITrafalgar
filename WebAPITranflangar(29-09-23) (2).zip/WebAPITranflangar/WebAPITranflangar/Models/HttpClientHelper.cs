﻿namespace WebAPITranflangar.Models
{
    using System.Net.Http.Headers;

    /// <summary>
    /// Class for Http Client Helper.
    /// </summary>
    public class HttpClientHelper
    {
        /// <summary>
        /// Http Client Property.
        /// </summary>
        private readonly HttpClient _httpClient;
        
        /// <summary>
        /// Http Client Helper Property.
        /// </summary>
        /// <param name="environmentValue">Contains the environmental value.</param>
        public HttpClientHelper(string environmentValue)
        {
            string baseCrmUrl = RetrieveBaseUrl(environmentValue);

            this._httpClient = new HttpClient
            {
                BaseAddress = new Uri(baseCrmUrl + $"api/data/v9.1/"),
                Timeout = TimeSpan.FromSeconds(300)
            };
            this._httpClient.DefaultRequestHeaders.Add("OData-MaxVersion", "4.0");
            this._httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        }

        /// <summary>
        /// Get Http Client Value class.
        /// </summary>
        /// <param name="environmentValue">Contains the environmental variable value.</param>
        /// <returns>Http Client Value.</returns>
        public HttpClient GetHttpClient(string environmentValue)
        {
            return this._httpClient;
        }

        /// <summary>
        /// RetrieveBaseUrl Method Class.
        /// </summary>
        /// <param name="environmentValue">Contains the environmental variable value.</param>
        /// <returns>returns a string value.</returns>
        public string? RetrieveBaseUrl(string environmentValue)
        {
            string baseUrl = string.Empty;
            var builder = WebApplication.CreateBuilder();
            if (environmentValue == "staging")
            {
                var section = builder.Configuration.GetSection($"app_config_staging");
                baseUrl =  section.GetValue(typeof(string), "CRMUrl").ToString();
            }
            else if (environmentValue =="prod")
            {
                var section = builder.Configuration.GetSection($"app_config_prod");
                baseUrl = section.GetValue(typeof(string), "CRMUrl").ToString();
            }
            return baseUrl;
        }
    }
}
