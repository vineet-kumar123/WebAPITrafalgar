﻿namespace WebAPITranflangar.Controllers
{
    using System.Globalization;
    using Microsoft.AspNetCore.Mvc;
    using WebAPITranflangar.Models;
    using RouteAttribute = Microsoft.AspNetCore.Mvc.RouteAttribute;
    using ActionNameAttribute = Microsoft.AspNetCore.Mvc.ActionNameAttribute;
    using Newtonsoft.Json.Linq;
    using System.Reflection;

    [ApiController]
    [Route("api/customerProfileUpdate")]
    public class CustomerProfileUpdateController
    {
        /// <summary>
        /// Contains the logger.
        /// </summary>
        readonly ILogger log;

        /// <summary>
        /// Contains the crmHelper class.
        /// </summary>
        readonly CRMHelper crmHelper = new();

        /// <summary>
        /// Contains the Ilogger.
        /// </summary>
        private readonly ILogger<CustomerProfileUpdateController> _logger;

        /// <summary>
        /// COntains the Ilogger class.
        /// </summary>
        /// <param name="logger"></param>
        public CustomerProfileUpdateController(ILogger<CustomerProfileUpdateController> logger)
        {
            _logger = logger;
        }

        /// <summary>
        /// Enquiry search WebApi Method.
        /// </summary>
        /// <param name="customer">Contains the JSON Payload</param>
        /// <returns>returns a string of entity object.</returns>
        /// <exception cref="Exception"></exception>
        /// 


        [HttpPost("CreateCustomerProfileUpdates")]
        [ActionName(nameof(CreateCustomerProfileUpdates))]
        public async Task<ResultObject> CreateCustomerProfileUpdates([FromBody] CustomerProfileCreate customerProfile)
        {
            var r = new ResultObject();
            try
            {

                JObject customerProfileupdate = new()
                {
                    ["duc_CustomerProfileUpdate"] = !string.IsNullOrEmpty(customerProfile.duc_CustomerProfileUpdate) ? customerProfile.duc_CustomerProfileUpdate : null,
                    ["duc_middlename"] = !string.IsNullOrEmpty(customerProfile.duc_middlename) ? customerProfile.duc_middlename : null,
                    ["duc_passportnumber"] = !string.IsNullOrEmpty(customerProfile.duc_passportnumber) ? customerProfile.duc_passportnumber : null,
                    ["duc_civilidexpirydate"] = !string.IsNullOrEmpty(customerProfile.duc_civilidexpirydate) ? customerProfile.duc_civilidexpirydate : null,
                    ["duc_birthday"] = !string.IsNullOrEmpty(customerProfile.duc_birthday) ? customerProfile.duc_birthday : null,
                    ["duc_gender"] = !string.IsNullOrEmpty(customerProfile.duc_gender.ToString()) ? customerProfile.duc_gender : null,
                    ["duc_address1_country"] = !string.IsNullOrEmpty(customerProfile.duc_address1_country) ? customerProfile.duc_address1_country : null,
                    ["duc_nationality"] = !string.IsNullOrEmpty(customerProfile.duc_nationality.ToString()) ? customerProfile.duc_nationality : null,
                    ["duc_professionofcustomer"] = !string.IsNullOrEmpty(customerProfile.duc_professionofcustomer.ToString()) ? customerProfile.duc_professionofcustomer : null,
                    ["duc_email"] = !string.IsNullOrEmpty(customerProfile.duc_email) ? customerProfile.duc_email : null,
                    ["duc_secondarymobilenumber"] = !string.IsNullOrEmpty(customerProfile.duc_secondarymobilenumber) ? customerProfile.duc_secondarymobilenumber : null,
                    ["duc_hometelephonenumber"] = !string.IsNullOrEmpty(customerProfile.duc_hometelephonenumber) ? customerProfile.duc_hometelephonenumber : null,
                    ["duc_address"] = !string.IsNullOrEmpty(customerProfile.duc_address) ? customerProfile.duc_address : null,
                    ["duc_area"] = !string.IsNullOrEmpty(customerProfile.duc_area.ToString()) ? customerProfile.duc_area : null,
                    ["duc_otherarea"] = !string.IsNullOrEmpty(customerProfile.duc_otherarea) ? customerProfile.duc_otherarea : null,
                    ["duc_postalcode"] = !string.IsNullOrEmpty(customerProfile.duc_postalcode) ? customerProfile.duc_postalcode : null,



                    ["duc_multi_hobbies"] = customerProfile.duc_Multi_Hobbies.ToString(),
                    //["duc_multi_hobbies"]=helperClass.CheckOptionsetValue(customerProfile.Duc_Multi_Hobbies),

                    ["duc_multi_brands"]= customerProfile.duc_multi_brands.ToString(),
                    ["duc_multi_favcolors"]= customerProfile.duc_multi_favcolors.ToString(),
                    ["duc_favcollections"]= !string.IsNullOrEmpty(customerProfile.duc_favcollections) ? customerProfile.duc_favcollections : null,
                    ["duc_howdidyouhearaboutus"] = !string.IsNullOrEmpty(customerProfile.duc_howdidyourhearaboutus.ToString()) ? customerProfile.duc_howdidyourhearaboutus : null,
                    ["duc_newsletter"] = !string.IsNullOrEmpty(customerProfile.duc_newsletter.ToString()) ? customerProfile.duc_newsletter : null,
                    ["duc_sms"] = !string.IsNullOrEmpty(customerProfile.duc_sms.ToString()) ? customerProfile.duc_sms : null
                };
                var contactId = await crmHelper.CreateEntityRecordInCRM("duc_customerprofileupdates", customerProfileupdate, customerProfile.EnvironmentValue, log);
                var baseAPIUrl = await crmHelper.RetrieveEnvironmentValue(customerProfile.EnvironmentValue, "diyar_CreateCustomerProfileUpdate", log);
                try
                {
                    var response = new HttpResponseMessage();
                   
                    var RegistrationAPI = baseAPIUrl.Replace("{CN.CUSTOMERPROFILEID}", contactId.ToString());
                    response = await crmHelper.RetrieveMultiple(RegistrationAPI, customerProfile.EnvironmentValue, log);
                    if (response != null)
                    {
                        r.code = Convert.ToInt16(response.StatusCode);
                        r.message = "response recieved";
                        r.data = response.Content.ReadAsStringAsync().Result;
                    }
                    else
                    {
                        //return GetRegistrationAndContactByEmail.ToString();
                    }

                    return r;
                }
                catch (Exception ex)
                {
                    throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in Contact API {0}", ex.Message));
                }

            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in UpdateCustomer API {0}", ex.Message));
            }
           
        }


        [HttpPost("EditProfile")]
        [ActionName(nameof(EditProfile))]
        public async Task<ResultObject> EditProfile([FromBody] CustomerProfileUpdate customerProfile)
        {
            var r = new ResultObject();
            try
            {

                JObject customerProfileupdate = new()
                {
                    ["duc_CustomerProfileUpdate"] = !string.IsNullOrEmpty(customerProfile.duc_CustomerProfileUpdate) ? customerProfile.duc_CustomerProfileUpdate : null,
                    ["duc_middlename"] = !string.IsNullOrEmpty(customerProfile.duc_middlename) ? customerProfile.duc_middlename : null,
                    ["duc_passportnumber"] = !string.IsNullOrEmpty(customerProfile.duc_passportnumber) ? customerProfile.duc_passportnumber : null,
                    ["duc_civilidexpirydate"] = !string.IsNullOrEmpty(customerProfile.duc_civilidexpirydate) ? customerProfile.duc_civilidexpirydate : null,
                    ["duc_birthday"] = !string.IsNullOrEmpty(customerProfile.duc_birthday) ? customerProfile.duc_birthday : null,
                    ["duc_gender"] = !string.IsNullOrEmpty(customerProfile.duc_gender.ToString()) ? customerProfile.duc_gender : null,
                    ["duc_address1_country"] = !string.IsNullOrEmpty(customerProfile.duc_address1_country) ? customerProfile.duc_address1_country : null,
                    ["duc_nationality"] = !string.IsNullOrEmpty(customerProfile.duc_nationality.ToString()) ? customerProfile.duc_nationality : null,
                    ["duc_professionofcustomer"] = !string.IsNullOrEmpty(customerProfile.duc_professionofcustomer.ToString()) ? customerProfile.duc_professionofcustomer : null,
                    ["duc_email"] = !string.IsNullOrEmpty(customerProfile.duc_email) ? customerProfile.duc_email : null,
                    ["duc_secondarymobilenumber"] = !string.IsNullOrEmpty(customerProfile.duc_secondarymobilenumber) ? customerProfile.duc_secondarymobilenumber : null,
                    ["duc_hometelephonenumber"] = !string.IsNullOrEmpty(customerProfile.duc_hometelephonenumber) ? customerProfile.duc_hometelephonenumber : null,
                    ["duc_address"] = !string.IsNullOrEmpty(customerProfile.duc_address) ? customerProfile.duc_address : null,
                    ["duc_area"] = !string.IsNullOrEmpty(customerProfile.duc_area.ToString()) ? customerProfile.duc_area : null,
                    ["duc_otherarea"] = !string.IsNullOrEmpty(customerProfile.duc_otherarea) ? customerProfile.duc_otherarea : null,
                    ["duc_postalcode"] = !string.IsNullOrEmpty(customerProfile.duc_postalcode) ? customerProfile.duc_postalcode : null,



                    ["duc_multi_hobbies"] = customerProfile.duc_Multi_Hobbies.ToString(),
                    //["duc_multi_hobbies"]=helperClass.CheckOptionsetValue(customerProfile.Duc_Multi_Hobbies),

                    ["duc_multi_brands"] = customerProfile.duc_multi_brands.ToString(),
                    ["duc_multi_favcolors"] = customerProfile.duc_multi_favcolors.ToString(),
                    ["duc_favcollections"] = !string.IsNullOrEmpty(customerProfile.duc_favcollections) ? customerProfile.duc_favcollections : null,
                    ["duc_howdidyouhearaboutus"] = !string.IsNullOrEmpty(customerProfile.duc_howdidyourhearaboutus.ToString()) ? customerProfile.duc_howdidyourhearaboutus : null,
                    ["duc_newsletter"] = !string.IsNullOrEmpty(customerProfile.duc_newsletter.ToString()) ? customerProfile.duc_newsletter : null,
                    ["duc_sms"] = !string.IsNullOrEmpty(customerProfile.duc_sms.ToString()) ? customerProfile.duc_sms : null
                };
                await crmHelper.UpdateEntityRecordInCRM("duc_customerprofileupdates", customerProfile.duc_CustomerProfileUpdateid, customerProfileupdate, customerProfile.EnvironmentValue, log);
                var baseAPIUrl = await crmHelper.RetrieveEnvironmentValue(customerProfile.EnvironmentValue, "diyar_CreateCustomerProfileUpdate", log);
                try
                {
                    var response = new HttpResponseMessage();

                    var RegistrationAPI = baseAPIUrl.Replace("{CN.CUSTOMERPROFILEID}", customerProfile.duc_CustomerProfileUpdateid);
                    response = await crmHelper.RetrieveMultiple(RegistrationAPI, customerProfile.EnvironmentValue, log);
                    if (response != null)
                    {
                        r.code = Convert.ToInt16(response.StatusCode);
                        r.message = "response recieved";
                        r.data = response.Content.ReadAsStringAsync().Result;
                    }
                    else
                    {
                        //return GetRegistrationAndContactByEmail.ToString();
                    }

                    return r;
                }
                catch (Exception ex)
                {
                    throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in Contact API {0}", ex.Message));
                }

            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in UpdateCustomer API {0}", ex.Message));
            }

        }

    }



}
