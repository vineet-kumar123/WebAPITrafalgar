﻿using WebAPITranflangar.Models;

namespace WebAPITranflangar.Interface
{
    public interface IWrapperTrafalgarCRM
    {
        List<WrapperTrafalgarCRM> GetAllMember();
        WrapperTrafalgarCRM GetMember(int id);
    }
}
