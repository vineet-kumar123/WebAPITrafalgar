﻿namespace WebAPITranflangar.Models
{
    using Microsoft.Xrm.Sdk;
    public class HelperClass
    { 
        public OptionSetValueCollection? CheckOptionsetValue(List<int> optionsetValueCollection)
        {
            if (optionsetValueCollection != null)
            {
                OptionSetValueCollection collection = new OptionSetValueCollection();
                foreach (var collect in optionsetValueCollection)
                {
                    collection.Add(new OptionSetValue(collect));
                }

                return collection;
            }
            else
            {
                return null;
            }

        }
    }
}
