﻿namespace WebAPITranflangar.Controllers
{
    using System.Globalization;
    using Microsoft.AspNetCore.Mvc;
    using WebAPITranflangar.Models;
    using RouteAttribute = Microsoft.AspNetCore.Mvc.RouteAttribute;
    using ActionNameAttribute = Microsoft.AspNetCore.Mvc.ActionNameAttribute;
    using Newtonsoft.Json.Linq;

    [ApiController]
    [Route("api/registration")]
    public class RegistrationController : ControllerBase
    {
        /// <summary>
        /// Contains the logger.
        /// </summary>
        readonly ILogger log;

        /// <summary>
        /// Contains the crmHelper class.
        /// </summary>
        readonly CRMHelper crmHelper = new();

        /// <summary>
        /// Contains the Ilogger.
        /// </summary>
        private readonly ILogger<RegistrationController> _logger;

        /// <summary>
        /// COntains the Ilogger class.
        /// </summary>
        /// <param name="logger"></param>
        public RegistrationController(ILogger<RegistrationController> logger)
        {
            _logger = logger;
        }

        /// <summary>
        /// Enquiry search WebApi Method.
        /// </summary>
        /// <param name="customer">Contains the JSON Payload</param>
        /// <returns>returns a string of entity object.</returns>
        /// <exception cref="Exception"></exception>
        /// 

        [HttpPost("RetrieveEnvironmentValue")]
        [ActionName(nameof(RetrieveEnvironmentValue))]
        public async Task<string> RetrieveEnvironmentValue(string environmentValue, string ODataAPIName)
        {
            string environmentalDefiniation = string.Empty;
            var builder = WebApplication.CreateBuilder();
            if (environmentValue == "staging")
            {
                var section = builder.Configuration.GetSection($"app_config_staging");
                environmentalDefiniation = section.GetValue(typeof(string), "environmentalDefiniationUrl").ToString();
            }
            else if (environmentValue == "prod")
            {
                var section = builder.Configuration.GetSection($"app_config_prod");
                environmentalDefiniation = section.GetValue(typeof(string), "environmentalDefiniationUrl").ToString();
            }
            string environmentalUrl = environmentalDefiniation.Replace("{ODataAPIName}", ODataAPIName);
            JObject environmentVariable = await crmHelper.Retrieve(environmentalUrl, environmentValue, log);
            return environmentVariable["defaultvalue"].ToString();
        }


       

        [HttpPost("GetRegistrationByRegistrationId")]
        [ActionName(nameof(GetRegistrationByRegistrationId))]
        public async Task<ResultObject?> GetRegistrationByRegistrationId([FromBody] Registration registration)
        {
            var baseAPIUrl = await RetrieveEnvironmentValue(registration.EnvironmentValue, "diyar_GetRegistrationByRegistrationId");
            try
            {
                var response = new HttpResponseMessage();
                var r = new ResultObject();
                var getRegistrationAPI = baseAPIUrl.Replace("{RE.REGISTRATIONID}", registration.registraionId);
                response = await crmHelper.RetrieveMultiple(getRegistrationAPI, registration.EnvironmentValue, log);
                if (response != null)
                {
                    r.code = Convert.ToInt16(response.StatusCode);
                    r.message = "response recieved";
                    r.data = response.Content.ReadAsStringAsync().Result;
                }
                else
                {
                    //return ducRegistrations.ToString();
                }

                return r;
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in GetCustomerByMobileAndFirstName API {0}", ex.Message));
            }
        }


        [HttpPost("GetRegistrationByMobile")]
        [ActionName(nameof(GetRegistrationByMobile))]
        public async Task<ResultObject?> GetRegistrationByMobile([FromBody] GetRegistrationByMobile Mobile)
        {
            var baseAPIUrl = await RetrieveEnvironmentValue(Mobile.EnvironmentValue, "diyar_GetRegistrationByMobile");
            try
            {
                var response = new HttpResponseMessage();
                var r = new ResultObject();
                var GetRegistrationByMobileAPI = baseAPIUrl.Replace("{RE.MOBILE}", Mobile.mobile);
                response = await crmHelper.RetrieveMultiple(GetRegistrationByMobileAPI, Mobile.EnvironmentValue, log);
                if (response != null)
                {
                    r.code = Convert.ToInt16(response.StatusCode);
                    r.message = "response recieved";
                    r.data = response.Content.ReadAsStringAsync().Result;
                }
                else
                {
                    //return ducGetRegistrationByMobile.ToString();
                }

                return r;
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in GetRegistrationByMobile API {0}", ex.Message));
            }
        }


        

        

        [HttpPost("GetRegistrationAndContactByEmail")]
        [ActionName(nameof(GetRegistrationAndContactByEmail))]
        public async Task<ResultObject?> GetRegistrationAndContactByEmail([FromBody] RegistrationContactEmail Email)
        {
            var baseAPIUrl = await RetrieveEnvironmentValue(Email.EnvironmentValue, "diyar_GetRegistrationAndContactByEmail");
            try
            {
                var response = new HttpResponseMessage();
                var r = new ResultObject();
                var RegistrationAPI = baseAPIUrl.Replace("{CN.EMAIL}", Email.Email);
                response = await crmHelper.RetrieveMultiple(RegistrationAPI, Email.EnvironmentValue, log);
                if (response != null)
                {
                    r.code = Convert.ToInt16(response.StatusCode);
                    r.message = "response recieved";
                    r.data = response.Content.ReadAsStringAsync().Result;
                }
                else
                {
                    //return GetRegistrationAndContactByEmail.ToString();
                }

                return r;
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in Contact API {0}", ex.Message));
            }
        }


        [HttpPost("GetRegistrationAndContactByMobile")]
        [ActionName(nameof(GetRegistrationAndContactByMobile))]
        public async Task<ResultObject?> GetRegistrationAndContactByMobile([FromBody] RegistrationContactMobile mobile)
        {
            var baseAPIUrl = await RetrieveEnvironmentValue(mobile.EnvironmentValue, "diyar_GetRegistrationAndContactByMobile");
            try
            {
                var response = new HttpResponseMessage();
                var r = new ResultObject();
                var RegistrationAPI = baseAPIUrl.Replace("{CN.MOBILE}", mobile.mobile);
                response = await crmHelper.RetrieveMultiple(RegistrationAPI, mobile.EnvironmentValue, log);
                if (response != null)
                {
                    r.code = Convert.ToInt16(response.StatusCode);
                    r.message = "response recieved";
                    r.data = response.Content.ReadAsStringAsync().Result;
                }
                else
                {
                    //return GetRegistrationAndContactByEmail.ToString();
                }

                return r;
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in Contact API {0}", ex.Message));
            }
        }


        [HttpPost("UpdateRegistration")]
        [ActionName(nameof(UpdateRegistration))]
        public async Task<string?> UpdateRegistration([FromBody] UpdateRegistration registration)
        {
            try
            {
                JObject registrationUpdate = new()
                {
                    ["duc_retrycount"] = !string.IsNullOrEmpty(registration.duc_retryCount) ? registration.duc_retryCount : null,
                    ["duc_registrationid"] = !string.IsNullOrEmpty(registration.duc_registraionId) ? registration.duc_registraionId : null,
                    ["duc_name"] = !string.IsNullOrEmpty(registration.duc_name) ? registration.duc_name : null,
                    ["duc_currentpassword "] = !string.IsNullOrEmpty(registration.duc_currentpassword) ? registration.duc_currentpassword : null,
                    ["duc_registrationstatus "] = !string.IsNullOrEmpty(registration.duc_registrationstatus) ? registration.duc_registrationstatus : null,
                    ["duc_contactId "] = !string.IsNullOrEmpty(registration.duc_contactId) ? registration.duc_contactId : null,



                };
                if (string.IsNullOrEmpty(registration.duc_registraionId))
                {
                    return "registration id is mandatory";
                }
                await crmHelper.UpdateEntityRecordInCRM("duc_registrations", registrationUpdate["duc_registrationid"].ToString(), registrationUpdate, registration.EnvironmentValue, log);
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in GetCustomerByMobileAndFirstName API {0}", ex.Message));
            }
            return string.Empty;

        }


        [HttpPost("Login")]
        [ActionName(nameof(Login))]
        public async Task<string?> Login([FromBody] Login login)
        {
            try
            {
                JObject Login = new()
                {
                    ["duc_loggedinpassword"] = !string.IsNullOrEmpty(login.duc_loggedInPassword) ? login.duc_loggedInPassword : null,

                };
                if (string.IsNullOrEmpty(login.duc_RegistrationId))
                {
                    return "RecordId is mandatory";
                }
                await crmHelper.UpdateEntityRecordInCRM("duc_registrations", login.duc_RegistrationId, Login, login.EnvironmentValue, log);
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in GetCustomerByMobileAndFirstName API {0}", ex.Message));
            }
            return string.Empty;

        }

        [HttpPost("CreateRegistration")]
        [ActionName(nameof(CreateRegistration))]
        public async Task<string> CreateRegistration([FromBody] CreateRegistration Registaration)
        {
            try
            {
                JObject registrationCreate = new()
                {

                    ["duc_mobile"] = !string.IsNullOrEmpty(Registaration.duc_mobile) ? Registaration.duc_mobile : null,
                    ["duc_contactId"] = !string.IsNullOrEmpty(Registaration.duc_contactId) ? Registaration.duc_contactId : null,
                    ["duc_link"] = !string.IsNullOrEmpty(Registaration.duc_link) ? Registaration.duc_link : null,
                   
                    ["duc_retrycount"] = !string.IsNullOrEmpty(Registaration.duc_retrycount.ToString()) ? Registaration.duc_retrycount : null,
                    ["duc_registrationstatus"] = !string.IsNullOrEmpty(Registaration.duc_registrationstatus.ToString()) ? Registaration.duc_registrationstatus : null,


                };
                var contact = await crmHelper.CreateEntityRecordInCRM("duc_registrations", registrationCreate, Registaration.EnvironmentValue, log);

            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in UpdateCustomer API {0}", ex.Message));
            }
            return string.Empty;

        }



    }
}
