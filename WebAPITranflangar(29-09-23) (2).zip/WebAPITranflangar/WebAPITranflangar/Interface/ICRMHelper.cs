﻿using Newtonsoft.Json.Linq;
using WebAPITranflangar.Models;


namespace WebAPITranflangar.Interface
{
    public interface ICRMHelper
    {
        /// <summary>
        /// Retrieve Single Records.
        /// </summary>
        /// <param name="oDataQuery"></param>
        /// <param name="log"></param>
        /// <param name="attempt"></param>
        /// <returns></returns>
        Task<JObject> Retrieve(string oDataQuery, string environmentValue, ILogger log);

        /// <summary>
        /// Retrieve Multiple records.
        /// </summary>
        /// <param name="oDataQuery"></param>
        /// <param name="log"></param>
        /// <returns></returns>
        Task<List<JObject>> RetrieveMultiple(string oDataQuery, string environmentValue, ILogger log);
    }
}
