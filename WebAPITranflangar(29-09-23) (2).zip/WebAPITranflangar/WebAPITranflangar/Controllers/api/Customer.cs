﻿namespace WebAPITranflangar.Controllers.api
{
    using System.Globalization;
    using Microsoft.AspNetCore.Mvc;
    using WebAPITranflangar.Models;
    using RouteAttribute = Microsoft.AspNetCore.Mvc.RouteAttribute;
    using ActionNameAttribute = Microsoft.AspNetCore.Mvc.ActionNameAttribute;
    using Newtonsoft.Json.Linq;

    [ApiController]
    [Route("api/Customer")]
    

    public class Customer
    {

        /// <summary>
        /// Contains the logger.
        /// </summary>
        readonly ILogger log;

        /// <summary>
        /// Contains the crmHelper class.
        /// </summary>
        readonly CRMHelper crmHelper = new();

        /// <summary>
        /// Contains the Ilogger.
        /// </summary>
        private readonly ILogger<Customer> _logger;

        /// <summary>
        /// COntains the Ilogger class.
        /// </summary>
        /// <param name="logger"></param>
        public Customer(ILogger<Customer> logger)
        {
            _logger = logger;
        }

        /// <summary>
        /// Enquiry search WebApi Method.
        /// </summary>
        /// <param name="customer">Contains the JSON Payload</param>
        /// <returns>returns a string of entity object.</returns>
        /// <exception cref="Exception"></exception>
        /// 

        ResultObject r = new ResultObject();


        [HttpPost("RetrieveEnvironmentValue")]
        [ActionName(nameof(RetrieveEnvironmentValue))]
        public async Task<string> RetrieveEnvironmentValue(string environmentValue, string ODataAPIName)
        {
            string environmentalDefiniation = string.Empty;
            var builder = WebApplication.CreateBuilder();
            if (environmentValue == "staging")
            {
                var section = builder.Configuration.GetSection($"app_config_staging");
                environmentalDefiniation = section.GetValue(typeof(string), "environmentalDefiniationUrl").ToString();
            }
            else if (environmentValue == "prod")
            {
                var section = builder.Configuration.GetSection($"app_config_prod");
                environmentalDefiniation = section.GetValue(typeof(string), "environmentalDefiniationUrl").ToString();
            }
            string environmentalUrl = environmentalDefiniation.Replace("{ODataAPIName}", ODataAPIName);
            JObject environmentVariable = await crmHelper.Retrieve(environmentalUrl, environmentValue, log);
            return environmentVariable["defaultvalue"].ToString();
        }


        [HttpPost("GetCustomerByMobileAndFirstName")]
        [ActionName(nameof(getCustomerByMobileAndFirstName))]
        public async Task<ResultObject?> getCustomerByMobileAndFirstName([FromBody] MobileFirstName mobile)
        {
            var baseAPIUrl = await RetrieveEnvironmentValue(mobile.EnvironmentValue, "diyar_getCustomerByMobileAndFirstName");
            try
            {
                //  List<JObject> contact = new List<JObject>();
                var response = new HttpResponseMessage();
                var r = new ResultObject();
                var getCustomerAPI = baseAPIUrl.Replace("{MP.MOBILENO}", mobile.Mobile).Replace("{MP.FIRSTNAME}", mobile.FirstName);
                response = await crmHelper.RetrieveMultiple(getCustomerAPI, mobile.EnvironmentValue, log);

                if (response != null)
                {
                    r.code = Convert.ToInt16(response.StatusCode);
                    r.message = "response recieved";
                    r.data = response.Content.ReadAsStringAsync().Result;
                }

                else
                {
                    //string jsonResult = "[" + string.Join(",", contact) + "]";
                    //return !string.IsNullOrEmpty(jsonResult) ? jsonResult : string.Empty;
                }
                return r;
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in GetCustomerByMobileAndFirstName API {0}", ex.Message));
            }
        }


        [HttpPost("GetCustomerByMobileOrEmail")]
        [ActionName(nameof(GetCustomerByMobileOrEmail))]
        public async Task<ResultObject?> GetCustomerByMobileOrEmail([FromBody] GetCustomerByMobileOrEmail MobEmail)
        {

            var baseAPIUrl = await RetrieveEnvironmentValue(MobEmail.EnvironmentValue, "diyar_GetCustomerByMobileOrEmail");
            try
            {
                var response = new HttpResponseMessage();
                var r = new ResultObject();
                var GetCustomerByMobileOrEmailAPI = baseAPIUrl.Replace("{MO.MOBILE}", MobEmail.mobile).Replace("{EM.EMAIL}", MobEmail.email);
                response = await crmHelper.RetrieveMultiple(GetCustomerByMobileOrEmailAPI, MobEmail.EnvironmentValue, log);
                if (response != null)
                {
                    r.code = Convert.ToInt16(response.StatusCode);
                    r.message = "response recieved";
                    r.data = response.Content.ReadAsStringAsync().Result;
                }
                else
                {
                    //return ducGetCustomerByMobileOrEmail.ToString();
                }
                return r;
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in GetCustomerByMobileOrEmail API {0}", ex.Message));
            }
        }


        [HttpPost("GetCustomerByContactId")]
        [ActionName(nameof(GetCustomerByContactId))]
        public async Task<ResultObject?> GetCustomerByContactId([FromBody] Contact contactsID)
        {
            var baseAPIUrl = await RetrieveEnvironmentValue(contactsID.EnvironmentValue, "diyar_GetCustomerByContactID");
            try
            {
                var response = new HttpResponseMessage();
                var r = new ResultObject();
                var ContactAPI = baseAPIUrl.Replace("{CN.CONTACTID}", contactsID.ContactID);
                response = await crmHelper.RetrieveMultiple(ContactAPI, contactsID.EnvironmentValue, log);
                if (response != null)
                {
                    r.code = Convert.ToInt16(response.StatusCode);
                    r.message = "response recieved";
                    r.data = response.Content.ReadAsStringAsync().Result;
                }
                else
                {
                    // return Contact.ToString();
                }

                return r;
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in Contact API {0}", ex.Message));
            }
        }


        [HttpPost("UpdateCustomer")]
        [ActionName(nameof(UpdateCustomer))]
        public async Task<ResultObject?> UpdateCustomer([FromBody] UpdateCustomer customer)
        {
            var r = new ResultObject();
            try
            {
                JObject UpdateCustomer = new()
                {
                    ["duc_firstname"] = !string.IsNullOrEmpty(customer.duc_firstname) ? customer.duc_firstname : null,
                    ["duc_middlename"] = !string.IsNullOrEmpty(customer.duc_middlename) ? customer.duc_middlename : null,
                    ["duc_lastname"] = !string.IsNullOrEmpty(customer.duc_lastname) ? customer.duc_lastname : null,
                    ["duc_mobileno"] = !string.IsNullOrEmpty(customer.duc_mobileno) ? customer.duc_mobileno : null,
                    ["duc_passportnumber"] = !string.IsNullOrEmpty(customer.duc_passportnumber) ? customer.duc_passportnumber : null,
                    ["duc_civilid"] = !string.IsNullOrEmpty(customer.duc_civilid) ? customer.duc_civilid : null,
                    ["duc_civilidexpirydate"] = !string.IsNullOrEmpty(customer.duc_civilidexpirydate) ? customer.duc_civilidexpirydate : null,
                    ["duc_birthday"] = !string.IsNullOrEmpty(customer.duc_birthday) ? customer.duc_birthday : null,
                    ["duc_gender"] = !string.IsNullOrEmpty(customer.duc_gender.ToString()) ? customer.duc_gender : null,
                    ["duc_nationality"] = !string.IsNullOrEmpty(customer.duc_nationality.ToString()) ? customer.duc_nationality : null,
                    ["duc_address1_country"] = !string.IsNullOrEmpty(customer.duc_address1_country) ? customer.duc_address1_country : null,
                    ["duc_professionofcustomer"] = !string.IsNullOrEmpty(customer.duc_professionofcustomer.ToString()) ? customer.duc_professionofcustomer : null,
                    ["duc_email"] = !string.IsNullOrEmpty(customer.duc_email) ? customer.duc_email : null,

                };

                await crmHelper.UpdateEntityRecordInCRM("duc_customerprofileupdates", customer.duc_customerprofileupdateid, UpdateCustomer, customer.EnvironmentValue, log);
                var baseAPIUrl = await crmHelper.RetrieveEnvironmentValue(customer.EnvironmentValue, "diyar_CreateCustomerProfileUpdate", log);
                try
                {
                    var response = new HttpResponseMessage();

                    var RegistrationAPI = baseAPIUrl.Replace("{CN.CUSTOMERPROFILEID}", customer.duc_customerprofileupdateid);
                    response = await crmHelper.RetrieveMultiple(RegistrationAPI, customer.EnvironmentValue, log);
                    if (response != null)
                    {
                        r.code = Convert.ToInt16(response.StatusCode);
                        r.message = "response recieved";
                        r.data = response.Content.ReadAsStringAsync().Result;
                    }
                    else
                    {
                        //return GetRegistrationAndContactByEmail.ToString();
                    }

                    return r;
                }
                catch (Exception ex)
                {
                    throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in Contact API {0}", ex.Message));
                }

            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in GetCustomerByMobileAndFirstName API {0}", ex.Message));
            }


        }


        [HttpPost("GetCustomerProfileData")]
        [ActionName(nameof(GetCustomerProfileData))]
        public async Task<ResultObject> GetCustomerProfileData([FromBody] Mobile mobileNo)
        {
            var r = new ResultObject();
            var response = new HttpResponseMessage();
            var baseAPIUrl = await crmHelper.RetrieveEnvironmentValue(mobileNo.EnvironmentValue, "getContact", log);
            try
            {
                var getContactAPI = baseAPIUrl.Replace("{MP.MOBILENO}", mobileNo.mobile);
                response = await crmHelper.RetrieveMultiple(getContactAPI, mobileNo.EnvironmentValue, log);
                if (response != null)
                {
                    r.code = Convert.ToInt16(response.StatusCode);
                    r.message = "response recieved";
                    r.data = response.Content.ReadAsStringAsync().Result;
                }
                else
                {
                    //return contact.ToString();
                }

                return r;
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in getContact API {0}", ex.Message));
            }
        }






    }
}
