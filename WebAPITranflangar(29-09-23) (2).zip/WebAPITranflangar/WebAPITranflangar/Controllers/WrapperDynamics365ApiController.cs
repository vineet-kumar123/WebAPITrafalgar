﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;
using System.Globalization;
using WebAPITranflangar.Models;

namespace WebAPITranflangar.Controllers
{
    using System.Globalization;
    using Microsoft.AspNetCore.Mvc;
    using WebAPITranflangar.Models;
    using RouteAttribute = Microsoft.AspNetCore.Mvc.RouteAttribute;
    using ActionNameAttribute = Microsoft.AspNetCore.Mvc.ActionNameAttribute;
    using Newtonsoft.Json.Linq;

    [ApiController]
    [Route("[controller]")]
    public class WrapperDynamics365ApiController : ControllerBase
    {
        /// <summary>
        /// Contains the logger.
        /// </summary>
        readonly ILogger log;

        /// <summary>
        /// Contains the crmHelper class.
        /// </summary>
        readonly CRMHelper crmHelper = new();

        /// <summary>
        /// Contains the Ilogger.
        /// </summary>
        private readonly ILogger<WrapperDynamics365ApiController> _logger;

        /// <summary>
        /// COntains the Ilogger class.
        /// </summary>
        /// <param name="logger"></param>
        public WrapperDynamics365ApiController(ILogger<WrapperDynamics365ApiController> logger)
        {
            _logger = logger;
        }

        /// <summary>
        /// Enquiry search WebApi Method.
        /// </summary>
        /// <param name="customer">Contains the JSON Payload</param>
        /// <returns>returns a string of entity object.</returns>
        /// <exception cref="Exception"></exception>
        [HttpPost("EnquirySearch")]
        [ActionName(nameof(EnquirySearch))]
        public async Task<string?> EnquirySearch([FromBody] Models.Customer customer)
        {
            var baseAPIUrl = await RetrieveEnvironmentValue(customer.EnvironmentValue, "EnquirySearch");
            try
            {
                var enquirySearchAPI = baseAPIUrl.Replace("{CR.CUSTOMERID}", customer.CustomerId);
                JObject ducEnquirySeach = await crmHelper.Retrieve(enquirySearchAPI, customer.EnvironmentValue, log);
                if (ducEnquirySeach  == null)
                {
                    return string.Empty;
                }
                else
                {
                    return ducEnquirySeach.ToString();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in enqirySearch API {0}", ex.Message));
            }
        }

        /// <summary>
        /// Enquiry Detail View WebApi Method.
        /// </summary>
        /// <param name="customer">Contains the JSON Payload</param>
        /// <returns>returns a string of entity object.</returns>
        /// <exception cref="Exception"></exception>
        [HttpPost("EnquiryDetailView")]
        [ActionName(nameof(EnquiryDetailView))]
        public async Task<string?> EnquiryDetailView([FromBody] Incident incident)
        {
            try
            {
                var baseAPIUrl = await RetrieveEnvironmentValue(incident.EnvironmentValue, "EnquiryDetailView");
                var EnquiryDetailViewAPI = baseAPIUrl.Replace("{IN.INCIDENTID}", incident.IncidentId);
                JObject ducEnquiryDetailView = await crmHelper.Retrieve(EnquiryDetailViewAPI, incident.EnvironmentValue, log);
                if (ducEnquiryDetailView == null)
                {
                    return string.Empty;
                }
                else
                {
                    return ducEnquiryDetailView.ToString();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in EnquiryDetailView API {0}", ex.Message));
            }
        }

        /// <summary>
        /// Open Order Search WebApi Method.
        /// </summary>
        /// <param name="customer">Contains the JSON Payload</param>
        /// <returns>returns a string of entity object.</returns>
        /// <exception cref="Exception"></exception>
        [HttpPost("OpenOrderSearch")]
        [ActionName(nameof(OpenOrderSearch))]
        public async Task<string> OpenOrderSearch([FromBody] Models.Customer customervalue)
        {
            try
            {
                var baseAPIUrl = await RetrieveEnvironmentValue(customervalue.EnvironmentValue, "OpenOrderSearch");
                var opernOrderSearchAPI = baseAPIUrl.Replace("{PH.CUSTOMERID}", customervalue.CustomerId);
                JObject ducOpenOrderSearch = await crmHelper.Retrieve(opernOrderSearchAPI, customervalue.EnvironmentValue, log);
                if (ducOpenOrderSearch == null)
                {
                    return string.Empty;
                }
                else
                {
                    return ducOpenOrderSearch.ToString();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in openOrderSearch API {0}", ex.Message));
            }
        }

        /// <summary>
        /// Open Order Details View WebApi Method.
        /// </summary>
        /// <param name="customer">Contains the JSON Payload</param>
        /// <returns>returns a string of entity object.</returns>
        /// <exception cref="Exception"></exception>
        [HttpPost("OpenOrderDetailsView")]
        [ActionName(nameof(OpenOrderDetailsView))]
        public async Task<string> OpenOrderDetailsView([FromBody] PurchaseHistory purchaseHistory)
        {
            try
            {
                var baseAPIUrl = await RetrieveEnvironmentValue(purchaseHistory.EnvironmentValue, "OpenOrderDetailsView");
                var opernOrderDetailsAPI = baseAPIUrl.Replace("{PH.PURCHASEHISTORYID}", purchaseHistory.PurchaseHistoryId);
                JObject ducOpenOrderDetailsView = await crmHelper.Retrieve(opernOrderDetailsAPI, purchaseHistory.EnvironmentValue, log);
                if (ducOpenOrderDetailsView == null)
                {
                    return string.Empty;
                }
                else
                {
                    return ducOpenOrderDetailsView.ToString();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in openOrderDetailsView API {0}", ex.Message));
            }
        }

        /// <summary>
        /// Repair search WebApi Method.
        /// </summary>
        /// <param name="customer">Contains the JSON Payload</param>
        /// <returns>returns a string of entity object.</returns>
        /// <exception cref="Exception"></exception>
        [HttpPost("RepairSearch")]
        [ActionName(nameof(RepairSearch))]
        public async Task<string> RepairSearch([FromBody] Models.Customer customervalue)
        {
            try
            {
                var baseAPIUrl = await RetrieveEnvironmentValue(customervalue.EnvironmentValue, "RepairSearch");
                var repairSearchAPI = baseAPIUrl.Replace("{CS.CUSTOMERID}", customervalue.CustomerId);
                JObject ducRepariSearch = await crmHelper.Retrieve(repairSearchAPI, customervalue.EnvironmentValue, log);
                if (ducRepariSearch == null)
                {
                    return string.Empty;
                }
                else
                {
                    return ducRepariSearch.ToString();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in RepairSearch API {0}", ex.Message));
            }

        }

        /// <summary>
        /// Repair Details APIs Method.
        /// </summary>
        /// <param name="customer">Contains the JSON Payload</param>
        /// <returns>returns a string of entity object.</returns>
        /// <exception cref="Exception"></exception>
        [HttpPost("RepairDetailView")]
        [ActionName(nameof(RepairDetailView))]
        public async Task<string> RepairDetailView([FromBody] ServiceHistory servicehistory)
        {
            try
            {
                var baseAPIUrl = await RetrieveEnvironmentValue(servicehistory.EnvironmentValue, "RepairDetailView");
                var repairDetailAPI = baseAPIUrl.Replace("{SH.SERVICEHISTORYID}", servicehistory.ServiceHistoryId);
                JObject ducRepairDetailView = await crmHelper.Retrieve(repairDetailAPI, servicehistory.EnvironmentValue, log);
                if (ducRepairDetailView == null)
                {
                    return string.Empty;
                }
                else
                {
                    return ducRepairDetailView.ToString();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in RepairDetailView API {0}", ex.Message));
            }

        }

        /// <summary>
        /// Purchase Search Method.
        /// </summary>
        /// <param name="customer">Contains the JSON Payload</param>
        /// <returns>returns a string of entity object.</returns>
        /// <exception cref="Exception"></exception>
        [HttpPost("PurchaseSearch")]
        [ActionName(nameof(PurchaseSearch))]
        public async Task<string> PurchaseSearch([FromBody] Models.Customer customervalue)
        {
            var baseAPIUrl = await RetrieveEnvironmentValue(customervalue.EnvironmentValue, "PurchaseSearch");
            try
            {
                var purchaseSearchAPI = baseAPIUrl.Replace("{CV.CUSTOMERID}", customervalue.CustomerId);
                JObject ducPurchaseSearch = await crmHelper.Retrieve(purchaseSearchAPI, customervalue.EnvironmentValue, log);
                if (ducPurchaseSearch ==null)
                {
                    return string.Empty;
                }
                else
                {
                    return ducPurchaseSearch.ToString();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in PurchseSearch API {0}", ex.Message));
            }
        }

        /// <summary>
        /// Purchase Detail View Method.
        /// </summary>
        /// <param name="customer">Contains the JSON Payload</param>
        /// <returns>returns a string of entity object.</returns>
        /// <exception cref="Exception"></exception>
        [HttpPost("PurchaseDetailView")]
        [ActionName(nameof(PurchaseDetailView))]
        public async Task<string> PurchaseDetailView([FromBody] PurchaseHistory purchasehistory)
        {
            var baseAPIUrl = await RetrieveEnvironmentValue(purchasehistory.EnvironmentValue, "WishList");
            try
            {
                var purchaseDetailViewAPI = baseAPIUrl.Replace("{PR.PURCHASEHISTORYID}", purchasehistory.PurchaseHistoryId);
                JObject ducPurhcaseDetailView = await crmHelper.Retrieve(purchaseDetailViewAPI, purchasehistory.EnvironmentValue, log);
                if (ducPurhcaseDetailView == null)
                {
                    return string.Empty;
                }
                else
                {
                    return ducPurhcaseDetailView.ToString();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in purchaseDetailView API {0}", ex.Message));
            }
        }

        /// <summary>
        /// Wish list Method.
        /// </summary>
        /// <param name="customer">Contains the JSON Payload</param>
        /// <returns>returns a string of entity object.</returns>
        /// <exception cref="Exception"></exception>
        [HttpPost("WishList")]
        [ActionName(nameof(WishList))]
        public async Task<string> WishList([FromBody] Models.Customer customerId)
        {
            var baseAPIUrl = await RetrieveEnvironmentValue(customerId.EnvironmentValue, "WishList");
            try
            {
                var wishListAPI = baseAPIUrl.Replace("{CR.CUSTOMERID}", customerId.CustomerId);
                JObject ducCustomerWishList = await crmHelper.Retrieve(wishListAPI, customerId.EnvironmentValue, log);
                if (ducCustomerWishList == null)
                {
                    return string.Empty;
                }
                else
                {
                    return ducCustomerWishList.ToString();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in wishlist API {0}", ex.Message));
            }

        }

        /// <summary>
        /// Get Contact Method.
        /// </summary>
        /// <param name="customer">Contains the JSON Payload</param>
        /// <returns>returns a string of entity object.</returns>
        /// <exception cref="Exception"></exception>
        [HttpPost("Contact")]
        [ActionName(nameof(getContact))]
        public async Task<string> getContact([FromBody] Mobile mobileNo)
        {
            var baseAPIUrl = await RetrieveEnvironmentValue(mobileNo.EnvironmentValue, "EnquirySearch");
            try
            {
                var getContactAPI = baseAPIUrl.Replace("{MP.MOBILENO}", mobileNo.mobile);
                JObject contact = await crmHelper.Retrieve(getContactAPI, mobileNo.EnvironmentValue, log);
                if (contact == null)
                {
                    return string.Empty;
                }
                else
                {
                    return contact.ToString();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in getContact API {0}", ex.Message));
            }
        }

        /// <summary>
        /// Customer Profile Update Method.
        /// </summary>
        /// <param name="customer">Contains the JSON Payload</param>
        /// <returns>returns a string value.</returns>
        /// <exception cref="Exception"></exception>
        [HttpPost("CustomerProfileUpdates")]
        [ActionName(nameof(UpdateCustomerprofile))]
        public async Task<string> UpdateCustomerprofile([FromBody] CustomerProfile customerProfile)
        {
            try
            {
                JObject customerProfileupdate = new()
                {
                    ["duc_firstname"]= !string.IsNullOrEmpty(customerProfile.FirstName) ? customerProfile.FirstName : null,
                    ["duc_middlename"]= !string.IsNullOrEmpty(customerProfile.MiddleName) ? customerProfile.MiddleName : null,
                    ["duc_lastname"]= !string.IsNullOrEmpty(customerProfile.LastName) ? customerProfile.LastName : null,
                    ["duc_passportnumber"]=!string.IsNullOrEmpty(customerProfile.PassportNumber) ? customerProfile.PassportNumber : null,
                    ["duc_civilid"]= !string.IsNullOrEmpty(customerProfile.CivilId) ? customerProfile.CivilId : null,
                    ["duc_civilidexpirydate"]= !string.IsNullOrEmpty(customerProfile.CivilidExpiryDate) ? customerProfile.CivilidExpiryDate : null,
                    ["duc_mobileno"]=!string.IsNullOrEmpty(customerProfile.MobileNo) ? customerProfile.MobileNo : null,
                    ["duc_email"]= !string.IsNullOrEmpty(customerProfile.Email) ? customerProfile.Email : null,
                    ["duc_birthday"]=!string.IsNullOrEmpty(customerProfile.Birthday) ? customerProfile.Birthday : null,
                    ["duc_gender"]=!string.IsNullOrEmpty(customerProfile.Gender.ToString()) ? customerProfile.Gender : null,
                    ["duc_address1_country"]=!string.IsNullOrEmpty(customerProfile.Address1_Country) ? customerProfile.Address1_Country : null,
                    ["duc_nationality"]= !string.IsNullOrEmpty(customerProfile.Nationality.ToString()) ? customerProfile.Nationality : null,
                    ["duc_professionofcustomer"]=!string.IsNullOrEmpty(customerProfile.ProfessionOfCustomer.ToString()) ? customerProfile.ProfessionOfCustomer : null,
                    ["duc_email"]= !string.IsNullOrEmpty(customerProfile.Email) ? customerProfile.Email : null,
                    ["duc_secondarymobilenumber"]= !string.IsNullOrEmpty(customerProfile.SecondaryMobileNumber) ? customerProfile.SecondaryMobileNumber : null,
                    ["duc_hometelephonenumber"]= !string.IsNullOrEmpty(customerProfile.HomeTelephoneNo) ? customerProfile.HomeTelephoneNo : null,
                    ["duc_address"]= !string.IsNullOrEmpty(customerProfile.Address) ? customerProfile.Address : null,
                    ["duc_area"]=!string.IsNullOrEmpty(customerProfile.Area.ToString()) ? customerProfile.Area : null,
                    ["duc_otherarea"]= !string.IsNullOrEmpty(customerProfile.OtherArea) ? customerProfile.OtherArea : null,
                    ["duc_postalcode"]= !string.IsNullOrEmpty(customerProfile.PostCode) ? customerProfile.PostCode : null,



                    //["duc_multi_hobbies"] =customerProfile.Duc_Multi_Hobbies,
                    //["duc_multi_hobbies"]=helperClass.CheckOptionsetValue(customerProfile.Duc_Multi_Hobbies),

                    //customerProfileupdate["duc_multi_brands"]= customerProfile.Duc_multi_brands;
                    //customerProfileupdate["duc_multi_favcolors"]= customerProfile.Duc_multi_favcolors;
                    //customerProfileupdate["duc_favcollections"]= customerProfile.Duc_favcollections;
                    ["duc_howdidyouhearaboutus"]= !string.IsNullOrEmpty(customerProfile.Duc_howdidyourhearaboutus.ToString()) ? customerProfile.Duc_howdidyourhearaboutus : null,
                    ["duc_newsletter"] = !string.IsNullOrEmpty(customerProfile.Duc_newsletter.ToString()) ? customerProfile.Duc_newsletter : null,
                    ["duc_sms"] = !string.IsNullOrEmpty(customerProfile.Duc_sms.ToString()) ? customerProfile.Duc_sms : null
                };
                var contactId = await crmHelper.CreateEntityRecordInCRM("duc_customerprofileupdates", customerProfileupdate, customerProfile.EnvironmentValue, log);

            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in UpdateCustomer API {0}", ex.Message));
            }
            return string.Empty;
        }

        /// <summary>
        /// Retrieve Environment ValueMethod.
        /// </summary>
        /// <param name="environmentValue">Contains the environmental Variable value.</param>
        /// <param name="ODataAPIName">Contains the Odata API name to search.</param>
        /// <returns>Returns the ODATA API.</returns>
        /// <exception cref="Exception"></exception>
        [HttpPost("RetrieveEnvironmentValue")]
        [ActionName(nameof(RetrieveEnvironmentValue))]
        public async Task<string> RetrieveEnvironmentValue(string environmentValue, string ODataAPIName)
        {
            string environmentalDefiniation = string.Empty;
            var builder = WebApplication.CreateBuilder();
            if (environmentValue == "staging")
            {
                var section = builder.Configuration.GetSection($"app_config_staging");
                environmentalDefiniation =  section.GetValue(typeof(string), "environmentalDefiniationUrl").ToString();
            }
            else if (environmentValue =="prod")
            {
                var section = builder.Configuration.GetSection($"app_config_prod");
                environmentalDefiniation = section.GetValue(typeof(string), "environmentalDefiniationUrl").ToString();
            }
            string environmentalUrl = environmentalDefiniation.Replace("{ODataAPIName}", ODataAPIName);
            JObject environmentVariable = await crmHelper.Retrieve(environmentalUrl, environmentValue, log);
            return environmentVariable["defaultvalue"].ToString();
        }


        [HttpPost("getCustomerByMobileAndFirstName")]
        [ActionName(nameof(getCustomerByMobileAndFirstName))]
        public async Task<string?> getCustomerByMobileAndFirstName([FromBody] MobileFirstName mobile)
        {
            var baseAPIUrl = await RetrieveEnvironmentValue(mobile.EnvironmentValue, "diyar_getCustomerByMobileAndFirstName");
            try
            {
                var getCustomerAPI = baseAPIUrl.Replace("{MP.MOBILENO}", mobile.Mobile).Replace("{MP.FIRSTNAME}", mobile.FirstName);
                JObject contact = await crmHelper.Retrieve(getCustomerAPI, mobile.EnvironmentValue, log);
                if (contact == null)
                {
                    return string.Empty;
                }
                else
                {
                    return contact.ToString();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in GetCustomerByMobileAndFirstName API {0}", ex.Message));
            }
        }


        [HttpPost("GetRegistrationByRegistrationId")]
        [ActionName(nameof(GetRegistrationByRegistrationId))]
        public async Task<string?> GetRegistrationByRegistrationId([FromBody] Registration registration)
        {
            var baseAPIUrl = await RetrieveEnvironmentValue(registration.EnvironmentValue, "diyar_GetRegistrationByRegistrationId");
            try
            {
                var getRegistrationAPI = baseAPIUrl.Replace("{RE.REGISTRATIONID}", registration.registraionId);
                JObject ducRegistrations = await crmHelper.Retrieve(getRegistrationAPI, registration.EnvironmentValue, log);
                if (ducRegistrations == null)
                {
                    return string.Empty;
                }
                else
                {
                    return ducRegistrations.ToString();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in GetCustomerByMobileAndFirstName API {0}", ex.Message));
            }
        }


        [HttpPost("GetRegistrationByMobile")]
        [ActionName(nameof(GetRegistrationByMobile))]
        public async Task<string?> GetRegistrationByMobile([FromBody] GetRegistrationByMobile Mobile)
        {
            var baseAPIUrl = await RetrieveEnvironmentValue(Mobile.EnvironmentValue, "diyar_GetRegistrationByMobile");
            try
            {
                var GetRegistrationByMobileAPI = baseAPIUrl.Replace("{RE.MOBILE}", Mobile.mobile);
                JObject ducGetRegistrationByMobile = await crmHelper.Retrieve(GetRegistrationByMobileAPI, Mobile.EnvironmentValue, log);
                if (ducGetRegistrationByMobile == null)
                {
                    return string.Empty;
                }
                else
                {
                    return ducGetRegistrationByMobile.ToString();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in GetRegistrationByMobile API {0}", ex.Message));
            }
        }


        [HttpPost("GetCustomerByMobileOrEmail")]
        [ActionName(nameof(GetCustomerByMobileOrEmail))]
        public async Task<string?> GetCustomerByMobileOrEmail([FromBody] GetCustomerByMobileOrEmail MobEmail)
        {
            var baseAPIUrl = await RetrieveEnvironmentValue(MobEmail.EnvironmentValue, "diyar_GetCustomerByMobileOrEmail");
            try
            {
                var GetCustomerByMobileOrEmailAPI = baseAPIUrl.Replace("{MO.MOBILE}", MobEmail.mobile).Replace("{EM.EMAIL}", MobEmail.email);
                JObject ducGetCustomerByMobileOrEmail = await crmHelper.Retrieve(GetCustomerByMobileOrEmailAPI, MobEmail.EnvironmentValue, log);
                if (ducGetCustomerByMobileOrEmail == null)
                {
                    return string.Empty;
                }
                else
                {
                    return ducGetCustomerByMobileOrEmail.ToString();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in GetCustomerByMobileOrEmail API {0}", ex.Message));
            }
        }


        [HttpPost("GetCustomerByContactId")]
        [ActionName(nameof(GetCustomerByContactId))]
        public async Task<string?> GetCustomerByContactId([FromBody] Contact contactsID)
        {
            var baseAPIUrl = await RetrieveEnvironmentValue(contactsID.EnvironmentValue, "diyar_GetCustomerByContactID");
            try
            {
                var ContactAPI = baseAPIUrl.Replace("{CN.CONTACTID}", contactsID.ContactID);
                JObject Contact = await crmHelper.Retrieve(ContactAPI, contactsID.EnvironmentValue, log);
                if (Contact == null)
                {
                    return string.Empty;
                }
                else
                {
                    return Contact.ToString();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in Contact API {0}", ex.Message));
            }
        }


     //   [HttpPost("GetRegistrationAndContactByEmail")]
      //  [ActionName(nameof(GetRegistrationAndContactByEmail))]
        //public async Task<string?> GetRegistrationAndContactByEmail([FromBody] RegistrationContactEmail Email)
        //{
        //    var baseAPIUrl = await RetrieveEnvironmentValue(Email.EnvironmentValue, "diyar_GetCustomerByContactID");
        //    try
        //    {
        //        var RegistrationAPI = baseAPIUrl.Replace("{CN.EMAIL}", Email.ContactEmail).Replace("{RE.EMAIL}",Email.RegistrationEmail);
        //        JObject GetRegistrationAndContactByEmail = await crmHelper.Retrieve(RegistrationAPI, Email.EnvironmentValue, log);
        //        if (GetRegistrationAndContactByEmail == null)
        //        {
        //            return string.Empty;
        //        }
        //        else
        //        {
        //            return GetRegistrationAndContactByEmail.ToString();
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in Contact API {0}", ex.Message));
        //    }
        //}


        //[HttpPost("GetRegistrationAndContactByMobile")]
        //[ActionName(nameof(GetRegistrationAndContactByMobile))]
        //public async Task<string?> GetRegistrationAndContactByMobile([FromBody] RegistrationContactMobile mobile)
        //{
        //    var baseAPIUrl = await RetrieveEnvironmentValue(mobile.EnvironmentValue, "diyar_GetCustomerByContactID");
        //    try
        //    {
        //        var RegistrationAPI = baseAPIUrl.Replace("{CN.MOBILE}", mobile.Contactmobile).Replace("{RE.MOBILE}", mobile.Registrationmobile);
        //        JObject GetRegistrationAndContactByEmail = await crmHelper.Retrieve(RegistrationAPI, mobile.EnvironmentValue, log);
        //        if (GetRegistrationAndContactByEmail == null)
        //        {
        //            return string.Empty;
        //        }
        //        else
        //        {
        //            return GetRegistrationAndContactByEmail.ToString();
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in Contact API {0}", ex.Message));
        //    }
        //}









        /*
        [HttpGet("MultipleContact")]
        [ActionName(nameof(getMultipleContact))]
        public async Task<string> getMultipleContact()
        {
            List<JObject> contact = new List<JObject>();
            try
            {
                contact = await crmHelper.RetrieveMultiple($"contacts?$select=fullname,duc_title,firstname,lastname,middlename,new_passportnumber,new_arealist,new_civilid,new_civilidexpirydate,birthdate,duc_multi_hobbies,duc_multi_brands,duc_multi_favcolors,duc_nationalityshortcode,duc_pacinumber,address1_country,jobtitle,new_reasonofpurchase_,emailaddress1,mobilephone,telephone1,address1_name,address1_telephone1,address1_line1,new_salutation,address1_postalcode,address1_stateorprovince,address1_county,duc_frontpicnationalid,duc_backpicnationalid,duc_newsletter,duc_sms,gendercode,duc_gender,duc_favcolorslist,duc_favcollections,new_nationalitylist,duc_brandslist,duc_howdidyouhearaboutus,duc_professionofcustomer,duc_hobbieslist,duc_hobbies,duc_favcolors,duc_brands,duc_secondarymobilenumber,modifiedon,duc_lastudatefromipad,createdon,duc_attachmenttype,statecode&$orderby=_createdby_value desc&$count=true&$top=3", log);
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in getContact API {0}", ex.Message));
            }

            string jsonResult = "[" + string.Join(",", contact) + "]";

            return !string.IsNullOrEmpty(jsonResult) ? jsonResult : string.Empty;
        }*/
    }
}




