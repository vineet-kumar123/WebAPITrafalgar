﻿namespace WebAPITranflangar.Models
{
    /// <summary>
    /// Class for Wrapper Trafalgar CRM.
    /// </summary>
    public class WrapperTrafalgarCRM
    {
        /// <summary>
        /// Gets or set for Member Id.
        /// </summary>
        public int MemberId { get; set; }

        /// <summary>
        /// Gets or set for FirstName.
        /// </summary>
        public string? FirstName { get; set; }

        /// <summary>
        /// Gets or set for LastName.
        /// </summary>
        public string? LastName { get; set; }

        /// <summary>
        /// Gets or set for Address.
        /// </summary>
        public string? Address { get; set; }

        /// <summary>
        /// Gets or set for EnvironmentValue.
        /// </summary>
        public string? EnvironmentValue { get; set; }
    }

    /// <summary>
    /// Class for Incident.
    /// </summary>
    public class Incident
    {
        /// <summary>
        /// Gets or sets for Incident ID.
        /// </summary>
        public string? IncidentId { get; set; }

        /// <summary>
        /// Gets or set for EnvironmentValue.
        /// </summary>
        public string? EnvironmentValue { get; set; }
    }

    public class Environment
    {
        /// <summary>
        /// Gets or sets for Incident ID.
        /// </summary>
       
        /// </summary>
        public string? EnvironmentValue { get; set; }
    }

    public class AssociatedContact
    {
        /// <summary>
        /// Gets or sets for Incident ID.
        /// </summary>

        /// </summary>
        public string? regardingobjectid_incident_customerid_value { get; set; }

        public string? EnvironmentValue { get; set; }
    }

    /// <summary>
    /// Class for Customer.
    /// </summary>
    public class Customer
    {
        /// <summary>
        /// Gets or sets for Customer Id.
        /// </summary>
        public string? CustomerId { get; set; }

        /// <summary>
        /// Gets or set for EnvironmentValue.
        /// </summary>
        public string? EnvironmentValue { get; set; }

    }

    /// <summary>
    /// Class for Customer Profile.
    /// </summary>
    public class CustomerProfile
    {
        /// <summary>
        /// Gets or set for First Name.
        /// </summary>
        public string? FirstName { get; set; }

        /// <summary>
        /// Gets or set for Last Name.
        /// </summary>
        public string? LastName { get; set; }

        /// <summary>
        /// Gets or set for Middle Name.
        /// </summary>
        public string? MiddleName { get; set; }

        /// <summary>
        /// Gets or set for Passport Number.
        /// </summary>
        public string? PassportNumber { get; set; }

        /// <summary>
        /// Gets or set for Civil Id.
        /// </summary>
        public string? CivilId { get; set; }

        /// <summary>
        /// Gets or set for Civil id Expiry Date.
        /// </summary>
        public string? CivilidExpiryDate { get; set; }

        /// <summary>
        /// Gets or set for Mobile No.
        /// </summary>
        public string? MobileNo { get; set; }

        /// <summary>
        /// Gets or set for Email.
        /// </summary>
        public string? Email { get; set; }

        /// <summary>
        /// Gets or set for Birthday.
        /// </summary>
        public string? Birthday { get; set; }

        /// <summary>
        /// Gets or set for Gender.
        /// </summary>
        public int? Gender { get; set; }

        /// <summary>
        /// Gets or set for Address1_Country.
        /// </summary>
        public string? Address1_Country { get; set; }

        /// <summary>
        /// Gets or set for Nationality.
        /// </summary>
        public int? Nationality { get; set; }

        /// <summary>
        /// Gets or set for Profession Of Customer.
        /// </summary>
        public int? ProfessionOfCustomer { get; set; }

        /// <summary>
        /// Gets or set for Duc Email.
        /// </summary>
        public string? Duc_Email { get; set; }

        /// <summary>
        /// Gets or set for Secondary Mobile Number.
        /// </summary>
        public string? SecondaryMobileNumber { get; set; }

        /// <summary>
        /// Gets or set for Home Telephone No.
        /// </summary>
        public string? HomeTelephoneNo { get; set; }

        /// <summary>
        /// Gets or set for Address.
        /// </summary>
        public string? Address { get; set; }

        /// <summary>
        /// Gets or set for Area.
        /// </summary>
        public int? Area { get; set; }

        /// <summary>
        /// Gets or set for Other Area.
        /// </summary>
        public string? OtherArea { get; set; }

        /// <summary>
        /// Gets or set for Post Code.
        /// </summary>
        public string? PostCode { get; set; }

        /// <summary>
        /// Gets or set for  Multi Hobbies.
        /// </summary>
        public List<int>? Duc_Multi_Hobbies { get; set; }

        /// <summary>
        /// Gets or set for multi brands.
        /// </summary>
        public List<int>? Duc_multi_brands { get; set; }

        /// <summary>
        /// Gets or set for multi favcolors.
        /// </summary>
        public List<int>? Duc_multi_favcolors { get; set; }

        /// <summary>
        /// Gets or set for fav collections.
        /// </summary>
        public List<int>? Duc_favcollections { get; set; }

        /// <summary>
        /// Gets or set for  how did your hear about us.
        /// </summary>
        public int? Duc_howdidyourhearaboutus { get; set; }

        /// <summary>
        /// Gets or set for news letter.
        /// </summary>
        public bool Duc_newsletter { get; set; }

        /// <summary>
        /// Gets or set for Sms.
        /// </summary>
        public bool Duc_sms { get; set; }

        /// <summary>
        /// Gets or set for EnvironmentValue.
        /// </summary>
        public string? EnvironmentValue { get; set; }
    }

    /// <summary>
    /// Class for Purchase History.
    /// </summary>
    public class PurchaseHistory
    {
        /// <summary>
        /// Gets or set for Purchase history Id.
        /// </summary>
        public string? PurchaseHistoryId { get; set; }

        /// <summary>
        /// Gets or set for EnvironmentValue.
        /// </summary>
        public string? EnvironmentValue { get; set; }
    }

    public class Order
    {
        /// <summary>
        /// Gets or set for Purchase history Id.
        /// </summary>
        public string? OrrderNo { get; set; }

        /// <summary>
        /// Gets or set for EnvironmentValue.
        /// </summary>
        public string? EnvironmentValue { get; set; }
    }

    public class InvoiceNumber
    {
        /// <summary>
        /// Gets or set for Purchase history Id.
        /// </summary>
        public string? InvioiceNo { get; set; }

        /// <summary>
        /// Gets or set for EnvironmentValue.
        /// </summary>
        public string? EnvironmentValue { get; set; }
    }

    /// <summary>
    /// Class for Service History.
    /// </summary>
    public class ServiceHistory
    {
        /// <summary>
        /// Gets or set for Service History Id.
        /// </summary>
        public string? ServiceHistoryId { get; set; }

        /// <summary>
        /// Gets or set for EnvironmentValue.
        /// </summary>
        public string? EnvironmentValue { get; set; }
    }

    public class JobCard
    {
        /// <summary>
        /// Gets or set for Job Card Id.
        /// </summary>
        public string? JobCardNo { get; set; }

        /// <summary>
        /// Gets or set for EnvironmentValue.
        /// </summary>
        public string? EnvironmentValue { get; set; }
    }

    /// <summary>
    /// Class for Mobile.
    /// </summary>
    public class Mobile
    {
        /// <summary>
        /// Gets or set for Mobile
        /// </summary>
        public string? mobile { get; set; }


        /// <summary>
        /// Gets or set for EnvironmentValue.
        /// </summary>
        public string? EnvironmentValue { get; set; }
    }

    public class MobileFirstName
    {
        /// <summary>
        /// Gets or sets for MobileFirstName
        /// </summary>
        public string? Mobile { get; set; }
        public string? FirstName { get; set; }

        /// <summary>
        /// Gets or set for EnvironmentValue.
        /// </summary>
        public string? EnvironmentValue { get; set; }

    }

    public class Registration
    {
        /// <summary>
        /// Gets or sets for MobileFirstName
        /// </summary>
        public string? registraionId { get; set; }


        /// <summary>
        /// Gets or set for EnvironmentValue.
        /// </summary>
        public string? EnvironmentValue { get; set; }

    }

    public class GetRegistrationByMobile
    {
        /// <summary>
        /// Gets or set for Get Registration For Mobile.
        /// </summary>
        public string? mobile { get; set; }



        /// <summary>
        /// Gets or set for EnvironmentValue.
        /// </summary>
        public string? EnvironmentValue { get; set; }
    }

    public class GetCustomerByMobileOrEmail
    {
        /// <summary>
        /// Gets or set for Get Customer By Mobile Or Email.
        /// </summary>
        public string? mobile { get; set; }

        public string? email { get; set; }

        /// <summary>
        /// Gets or set for EnvironmentValue.
        /// </summary>
        public string? EnvironmentValue { get; set; }
    }

    public class Contact
    {
        /// <summary>
        /// Gets or set for Get Customer By ContactID.
        /// </summary>
        public string? ContactID { get; set; }

        /// <summary>
        /// Gets or set for EnvironmentValue.
        /// </summary>
        public string? EnvironmentValue { get; set; }
    }

    public class RegistrationContactEmail
    {
        /// <summary>
        /// Gets or set for Get Customer By ContactID.
        /// </summary>
        public string? Email { get; set; }

        //public string? RegistrationEmail { get; set; }

        /// <summary>
        /// Gets or set for EnvironmentValue.
        /// </summary>
        public string? EnvironmentValue { get; set; }
    }

    public class UpdateRegistration
    {
        /// <summary>
        /// Gets or set for Get Customer By ContactID.
        /// </summary>
        public string? duc_retryCount { get; set; }

        public string? duc_registraionId { get; set; }

        public string? duc_name { get; set; }

        public string? duc_currentpassword { get; set; }

        public string? duc_registrationstatus { get; set; }

        public string? duc_contactId { get; set; }


        /// <summary>
        /// Gets or set for EnvironmentValue.
        /// </summary>
        public string? EnvironmentValue { get; set; }
    }

    public class ChangePassword
    {
        public string? duc_registraionId { get; set; }

        public string? duc_currentpassword { get; set; }

        /// <summary>
        /// Gets or set for EnvironmentValue.
        /// </summary>
        public string? EnvironmentValue { get; set; }
    }

    public class ResetPassword
    {
        public string? duc_registraionId { get; set; }

        public string? duc_link { get; set; }

        public bool? duc_sendresetpasswordlink { get; set; }

        /// <summary>
        /// Gets or set for EnvironmentValue.
        /// </summary>
        public string? EnvironmentValue { get; set; }
    }

    public class PasswordKeyCheck
    {
        public string? duc_registraionId { get; set; }

        public string? duc_forgotpasswordkeyfromsource { get; set; }


        /// <summary>
        /// Gets or set for EnvironmentValue.
        /// </summary>
        public string? EnvironmentValue { get; set; }
    }

    public class Login
    {
        /// <summary>
        /// Gets or set for Get Customer By ContactID.
        /// </summary>
        public string? duc_loggedInPassword { get; set; }
        public string? duc_RegistrationId { get; set; }



        /// <summary>
        /// Gets or set for EnvironmentValue.
        /// </summary>
        public string? EnvironmentValue { get; set; }
    }

    public class RegistrationContactMobile
    {
        /// <summary>
        /// Gets or set for Get Customer By ContactID.
        /// </summary>
        public string? mobile { get; set; }

        //public string? Registrationmobile { get; set; }

        /// <summary>
        /// Gets or set for EnvironmentValue.
        /// </summary>
        public string? EnvironmentValue { get; set; }
    }


    public class CreateCustomer
    {
        /// <summary>
        /// Gets or set for First Name.
        /// </summary>
        public string? FirstName { get; set; }

        /// <summary>
        /// Gets or set for Middle Name.
        /// </summary>
        public string? MiddleName { get; set; }

        /// <summary>
        /// Gets or set for Last Name.
        /// </summary>
        public string? LastName { get; set; }

        /// <summary>
        /// Gets or set for Mobile No.
        /// </summary>
        public string? MobilePhone { get; set; }

        /// <summary>
        /// Gets or set for Passport Number.
        /// </summary>
        public string? new_PassportNumber { get; set; }

        /// <summary>
        /// Gets or set for Civil Id.
        /// </summary>
        public string? new_CivilId { get; set; }


        /// <summary>
        /// Gets or set for Address1_Country.
        /// </summary>
        public string? Address1_Country { get; set; }

        /// <summary>
        /// Gets or set for Civil id Expiry Date.
        /// </summary>
        public string? new_CivilidExpiryDate { get; set; }

        /// <summary>
        /// Gets or set for Birthday.
        /// </summary>
        public string? Birthday { get; set; }

        /// <summary>
        /// Gets or set for Gender.
        /// </summary>
        public int? GenderCode { get; set; }

        /// <summary>
        /// Gets or set for Nationality.
        /// </summary>
        public int? new_Nationality { get; set; }

        /// <summary>
        /// Gets or set for Profession Of Customer.
        /// </summary>
        public int? duc_ProfessionOfCustomer { get; set; }

        /// <summary>
        /// Gets or set for Email.
        /// </summary>
        public string? EmailAddress1 { get; set; }

        /// <summary>
        /// Gets or set for EnvironmentValue.
        /// </summary>
        public string? EnvironmentValue { get; set; }
    }

    public class CreateRegistration
    {
        /// <summary>
        /// Gets or set for First Name.
        /// </summary>
        public string? duc_mobile { get; set; }
        public string? duc_contactId { get; set; }


        public string? duc_link { get; set; }

        public int? duc_retrycount { get; set; }

        public int? duc_registrationstatus { get; set; }


        /// <summary>
        /// Gets or set for Last Name.
        /// </summary>

        /// <summary>
        /// Gets or set for EnvironmentValue.
        /// </summary>
        public string? EnvironmentValue { get; set; }
    }


    public class ResultObject
    {
        public int code { get; set; }
        public string message { get; set; }
        public object data { get; set; }
    }

    public class CustomerProfileCreate
    {

        public string? duc_CustomerProfileUpdate { get; set; }

        /// <summary>
        /// Gets or set for First Name.
        /// </summary>

        public string? duc_middlename { get; set; }

        /// <summary>
        /// Gets or set for Passport Number.
        /// </summary>
        public string? duc_passportnumber { get; set; }


        /// <summary>
        /// Gets or set for Civil id Expiry Date.
        /// </summary>
        public string? duc_civilidexpirydate { get; set; }

        /// <summary>
        /// Gets or set for Birthday.
        /// </summary>
        public string? duc_birthday { get; set; }

        /// <summary>
        /// Gets or set for Gender.
        /// </summary>
        public int? duc_gender { get; set; }

        /// <summary>
        /// Gets or set for Nationality.
        /// </summary>
        public int? duc_nationality { get; set; }

        /// <summary>
        /// Gets or set for Address1_Country.
        /// </summary>
        public string? duc_address1_country { get; set; }

        /// <summary>
        /// Gets or set for Profession Of Customer.
        /// </summary>
        public int? duc_professionofcustomer { get; set; }

        /// <summary>
        /// Gets or set for Email.
        /// </summary>
        public string? duc_email { get; set; }

        /// <summary>
        /// Gets or set for Mobile No.
        /// </summary>
        public string? duc_secondarymobilenumber { get; set; }

        /// <summary>
        /// Gets or set for Home Telephone No.
        /// </summary>
        public string? duc_hometelephonenumber { get; set; }

        /// <summary>
        /// Gets or set for Address.
        /// </summary>
        public string? duc_address { get; set; }

        /// <summary>
        /// Gets or set for Area.
        /// </summary>
        public int? duc_area { get; set; }

        /// <summary>
        /// Gets or set for Other Area.
        /// </summary>
        public string? duc_otherarea { get; set; }

        /// <summary>
        /// Gets or set for Post Code.
        /// </summary>
        public string? duc_postalcode { get; set; }

        /// <summary>
        /// Gets or set for  Multi Hobbies.
        /// </summary>
        public string? duc_Multi_Hobbies { get; set; }

        /// <summary>
        /// Gets or set for multi brands.
        /// </summary>
        public string? duc_multi_brands { get; set; }

        /// <summary>
        /// Gets or set for multi favcolors.
        /// </summary>
        public string? duc_multi_favcolors { get; set; }

        /// <summary>
        /// Gets or set for fav collections.
        /// </summary>
        public string? duc_favcollections { get; set; }

        /// <summary>
        /// Gets or set for  how did your hear about us.
        /// </summary>
        public int? duc_howdidyourhearaboutus { get; set; }

        /// <summary>
        /// Gets or set for news letter.
        /// </summary>
        public bool duc_newsletter { get; set; }


        /// <summary>
        /// Gets or set for Sms.
        /// </summary>
        public bool duc_sms { get; set; }

        /// <summary>
        /// Gets or set for EnvironmentValue.
        /// </summary>
        public string? EnvironmentValue { get; set; }
    }

    public class CustomerProfileUpdate
    {

        public string? duc_CustomerProfileUpdateid { get; set; }

        public string? duc_CustomerProfileUpdate { get; set; }

        /// <summary>
        /// Gets or set for First Name.
        /// </summary>

        public string? duc_middlename { get; set; }

        /// <summary>
        /// Gets or set for Passport Number.
        /// </summary>
        public string? duc_passportnumber { get; set; }


        /// <summary>
        /// Gets or set for Civil id Expiry Date.
        /// </summary>
        public string? duc_civilidexpirydate { get; set; }

        /// <summary>
        /// Gets or set for Birthday.
        /// </summary>
        public string? duc_birthday { get; set; }

        /// <summary>
        /// Gets or set for Gender.
        /// </summary>
        public int? duc_gender { get; set; }

        /// <summary>
        /// Gets or set for Nationality.
        /// </summary>
        public int? duc_nationality { get; set; }

        /// <summary>
        /// Gets or set for Address1_Country.
        /// </summary>
        public string? duc_address1_country { get; set; }

        /// <summary>
        /// Gets or set for Profession Of Customer.
        /// </summary>
        public int? duc_professionofcustomer { get; set; }

        /// <summary>
        /// Gets or set for Email.
        /// </summary>
        public string? duc_email { get; set; }

        /// <summary>
        /// Gets or set for Mobile No.
        /// </summary>
        public string? duc_secondarymobilenumber { get; set; }

        /// <summary>
        /// Gets or set for Home Telephone No.
        /// </summary>
        public string? duc_hometelephonenumber { get; set; }

        /// <summary>
        /// Gets or set for Address.
        /// </summary>
        public string? duc_address { get; set; }

        /// <summary>
        /// Gets or set for Area.
        /// </summary>
        public int? duc_area { get; set; }

        /// <summary>
        /// Gets or set for Other Area.
        /// </summary>
        public string? duc_otherarea { get; set; }

        /// <summary>
        /// Gets or set for Post Code.
        /// </summary>
        public string? duc_postalcode { get; set; }

        /// <summary>
        /// Gets or set for  Multi Hobbies.
        /// </summary>
        public string? duc_Multi_Hobbies { get; set; }

        /// <summary>
        /// Gets or set for multi brands.
        /// </summary>
        public string? duc_multi_brands { get; set; }

        /// <summary>
        /// Gets or set for multi favcolors.
        /// </summary>
        public string? duc_multi_favcolors { get; set; }

        /// <summary>
        /// Gets or set for fav collections.
        /// </summary>
        public string? duc_favcollections { get; set; }

        /// <summary>
        /// Gets or set for  how did your hear about us.
        /// </summary>
        public int? duc_howdidyourhearaboutus { get; set; }

        /// <summary>
        /// Gets or set for news letter.
        /// </summary>
        public bool duc_newsletter { get; set; }


        /// <summary>
        /// Gets or set for Sms.
        /// </summary>
        public bool duc_sms { get; set; }

        /// <summary>
        /// Gets or set for EnvironmentValue.
        /// </summary>
        public string? EnvironmentValue { get; set; }
    }

    public class UpdateCustomer
    {

        public string? duc_customerprofileupdateid { get; set; }
        /// <summary>
        /// Gets or set for First Name.
        /// </summary>
        public string? duc_firstname { get; set; }


        public string? duc_middlename { get; set; }

        public string? duc_lastname { get; set; }

        public string? duc_mobileno { get; set; }

        public string? duc_passportnumber { get; set; }

        public string? duc_civilid { get; set; }

        public string? duc_civilidexpirydate { get; set; }

        public string? duc_birthday { get; set; }


        public int? duc_gender { get; set; }

        public int? duc_nationality { get; set; }

        public string? duc_address1_country { get; set; }

        public int? duc_professionofcustomer { get; set; }

        public string? duc_email { get; set; }


        /// <summary>
        /// Gets or set for Last Name.
        /// </summary>

        /// <summary>
        /// Gets or set for EnvironmentValue.
        /// </summary>
        public string? EnvironmentValue { get; set; }
    }

    public class AddEnquiry
    {
        /// <summary>
        /// Gets or set for Get Customer By ContactID.
        /// </summary>
        public string? CustomerId_Contact { get; set; }
        public string? CaseOriginCode { get; set; }

        public string? title { get; set; }

        public int? CaseTypeCode { get; set; }

        public string? description { get; set; }



        /// <summary>
        /// Gets or set for EnvironmentValue.
        /// </summary>
        public string? EnvironmentValue { get; set; }
    }


    public class EnquiryAttachment
    {
        /// <summary>
        /// Gets or set for Get Customer By ContactID.
        /// </summary>
        /// 
        public bool? IsDocument { get; set; }
        public string? objecttypecode { get; set; }
        public string? objectId_incident { get; set; }

        public string? filename { get; set; }



        public string? mimetype { get; set; }

        public string? documentBody { get; set; }



        /// <summary>
        /// Gets or set for EnvironmentValue.
        /// </summary>
        public string? EnvironmentValue { get; set; }
    }
}

