﻿namespace WebAPITranflangar.Controllers
{
    using System.Globalization;
    using Microsoft.AspNetCore.Mvc;
    using WebAPITranflangar.Models;
    using RouteAttribute = Microsoft.AspNetCore.Mvc.RouteAttribute;
    using ActionNameAttribute = Microsoft.AspNetCore.Mvc.ActionNameAttribute;
    using Newtonsoft.Json.Linq;
    using System.Reflection;


    [ApiController]
    [Route("api/WishList")]
    public class WishListController
    {
        /// <summary>
        /// Contains the logger.
        /// </summary>
        readonly ILogger log;

        /// <summary>
        /// Contains the crmHelper class.
        /// </summary>
        readonly CRMHelper crmHelper = new();

        /// <summary>
        /// Contains the Ilogger.
        /// </summary>
        private readonly ILogger<WishListController> _logger;

        /// <summary>
        /// COntains the Ilogger class.
        /// </summary>
        /// <param name="logger"></param>
        public WishListController(ILogger<WishListController> logger)
        {
            _logger = logger;
        }


        [HttpPost("GetAllWishList")]
        [ActionName(nameof(GetAllWishList))]
        public async Task<ResultObject> GetAllWishList([FromBody] Models.Customer customerId)
        {
            var r = new ResultObject();
            var baseAPIUrl = await crmHelper.RetrieveEnvironmentValue(customerId.EnvironmentValue, "WishList",log);
            try
            {
                var response = new HttpResponseMessage();
                var wishListAPI = baseAPIUrl.Replace("{CR.CUSTOMERID}", customerId.CustomerId);
                response = await crmHelper.RetrieveMultiple(wishListAPI, customerId.EnvironmentValue, log);
                if (response != null)
                {
                    r.code = Convert.ToInt16(response.StatusCode);
                    r.message = "response recieved";
                    r.data = response.Content.ReadAsStringAsync().Result;
                }
                else
                {
                    //return ducCustomerWishList.ToString();
                }

                return r;
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in wishlist API {0}", ex.Message));
            }

        }

    }
}
