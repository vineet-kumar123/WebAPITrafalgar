﻿namespace WebAPITranflangar.Controllers
{
    using System.Globalization;
    using Microsoft.AspNetCore.Mvc;
    using WebAPITranflangar.Models;
    using RouteAttribute = Microsoft.AspNetCore.Mvc.RouteAttribute;
    using ActionNameAttribute = Microsoft.AspNetCore.Mvc.ActionNameAttribute;
    using Newtonsoft.Json.Linq;
    using System.Reflection;

    [ApiController]
    [Route("api/Repair")]
    public class RepairController
    {
        /// <summary>
        /// Contains the logger.
        /// </summary>
        readonly ILogger log;

        /// <summary>
        /// Contains the crmHelper class.
        /// </summary>
        readonly CRMHelper crmHelper = new();

        /// <summary>
        /// Contains the Ilogger.
        /// </summary>
        private readonly ILogger<RepairController> _logger;

        /// <summary>
        /// COntains the Ilogger class.
        /// </summary>
        /// <param name="logger"></param>
        public RepairController(ILogger<RepairController> logger)
        {
            _logger = logger;
        }

        /// <summary>
        /// Enquiry search WebApi Method.
        /// </summary>
        /// <param name="customer">Contains the JSON Payload</param>
        /// <returns>returns a string of entity object.</returns>
        /// <exception cref="Exception"></exception>
        /// 


        /// <summary>
        /// Repair search WebApi Method.
        /// </summary>
        /// <param name="customer">Contains the JSON Payload</param>
        /// <returns>returns a string of entity object.</returns>
        /// <exception cref="Exception"></exception>
        [HttpPost("SearchRepair")]
        [ActionName(nameof(SearchRepair))]
        public async Task<ResultObject> SearchRepair([FromBody] Models.Customer customervalue)
        {
            var r = new ResultObject();
            var baseAPIUrl = await crmHelper.RetrieveEnvironmentValue(customervalue.EnvironmentValue, "RepairSearch",log);
            try
            {
                var response = new HttpResponseMessage();
                var repairSearchAPI = baseAPIUrl.Replace("{CS.CUSTOMERID}", customervalue.CustomerId);
                response = await crmHelper.RetrieveMultiple(repairSearchAPI, customervalue.EnvironmentValue, log);
                if (response != null)
                {
                    r.code = Convert.ToInt16(response.StatusCode);
                    r.message = "response recieved";
                    r.data = response.Content.ReadAsStringAsync().Result;
                }
                else
                {
                    //return ducRepariSearch.ToString();
                }

                return r;
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in RepairSearch API {0}", ex.Message));
            }

        }

        /// <summary>
        /// Repair Details APIs Method.
        /// </summary>
        /// <param name="customer">Contains the JSON Payload</param>
        /// <returns>returns a string of entity object.</returns>
        /// <exception cref="Exception"></exception>
        [HttpPost("GetRepairById")]
        [ActionName(nameof(GetRepairById))]
        public async Task<ResultObject> GetRepairById([FromBody] ServiceHistory servicehistory)
        {
            var r = new ResultObject();
            var baseAPIUrl = await crmHelper.RetrieveEnvironmentValue(servicehistory.EnvironmentValue, "RepairDetailView",log);
            try
            {
                var response = new HttpResponseMessage();
                var repairDetailAPI = baseAPIUrl.Replace("{SH.SERVICEHISTORYID}", servicehistory.ServiceHistoryId);
                response = await crmHelper.RetrieveMultiple(repairDetailAPI, servicehistory.EnvironmentValue, log);
                if (response != null)
                {
                    r.code = Convert.ToInt16(response.StatusCode);
                    r.message = "response recieved";
                    r.data = response.Content.ReadAsStringAsync().Result;
                }
                else
                {
                    //return ducRepairDetailView.ToString();
                }

                return r;
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in RepairDetailView API {0}", ex.Message));
            }

        }


        [HttpPost("GetRepairByJobCardNo")]
        [ActionName(nameof(GetRepairByJobCardNo))]
        public async Task<ResultObject> GetRepairByJobCardNo([FromBody] JobCard jobId)
        {
            var r = new ResultObject();
            var baseAPIUrl = await crmHelper.RetrieveEnvironmentValue(jobId.EnvironmentValue, "diyar_GetRepairsByJobCardNo", log);
            try
            {
                var response = new HttpResponseMessage();
                var repairDetailAPI = baseAPIUrl.Replace("{JC.NO}", jobId.JobCardNo);
                response = await crmHelper.RetrieveMultiple(repairDetailAPI, jobId.EnvironmentValue, log);
                if (response != null)
                {
                    r.code = Convert.ToInt16(response.StatusCode);
                    r.message = "response recieved";
                    r.data = response.Content.ReadAsStringAsync().Result;
                }
                else
                {
                    //return ducRepairDetailView.ToString();
                }

                return r;
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in RepairDetailView API {0}", ex.Message));
            }

        }

    }
}
