﻿namespace WebAPITranflangar.Controllers
{
    using System.Globalization;
    using Microsoft.AspNetCore.Mvc;
    using WebAPITranflangar.Models;
    using RouteAttribute = Microsoft.AspNetCore.Mvc.RouteAttribute;
    using ActionNameAttribute = Microsoft.AspNetCore.Mvc.ActionNameAttribute;
    using Newtonsoft.Json.Linq;
    using System.Reflection;

    [ApiController]
    [Route("api/Common")]
    public class CommonController
    {
        /// <summary>
        /// Contains the logger.
        /// </summary>
        readonly ILogger log;

        /// <summary>
        /// Contains the crmHelper class.
        /// </summary>
        readonly CRMHelper crmHelper = new();

        /// <summary>
        /// Contains the Ilogger.
        /// </summary>
        private readonly ILogger<CommonController> _logger;

        /// <summary>
        /// COntains the Ilogger class.
        /// </summary>
        /// <param name="logger"></param>
        public CommonController(ILogger<CommonController> logger)
        {
            _logger = logger;
        }


        [HttpPost("GetNationalityList")]
        [ActionName(nameof(GetNationalityList))]
        public async Task<ResultObject> GetNationalityList([FromBody] Environment environment)
        {
            var r = new ResultObject();
            var baseAPIUrl = await crmHelper.RetrieveEnvironmentValue(environment.EnvironmentValue, "diyar_GetNationalityList", log);
            try
            {
                var response = new HttpResponseMessage();
                response = await crmHelper.RetrieveMultiple(baseAPIUrl, environment.EnvironmentValue, log);
                if (response != null)
                {
                    r.code = Convert.ToInt16(response.StatusCode);
                    r.message = "response recieved";
                    r.data = response.Content.ReadAsStringAsync().Result;
                }
                else
                {
                    //return ducCustomerWishList.ToString();
                }

                return r;
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in wishlist API {0}", ex.Message));
            }

        }

        [HttpPost("GetSalutation")]
        [ActionName(nameof(GetSalutation))]
        public async Task<ResultObject> GetSalutation([FromBody] Environment environment)
        {
            var r = new ResultObject();
            var baseAPIUrl = await crmHelper.RetrieveEnvironmentValue(environment.EnvironmentValue, "diyar_GetSalutation", log);
            try
            {
                var response = new HttpResponseMessage();
                response = await crmHelper.RetrieveMultiple(baseAPIUrl, environment.EnvironmentValue, log);
                if (response != null)
                {
                    r.code = Convert.ToInt16(response.StatusCode);
                    r.message = "response recieved";
                    r.data = response.Content.ReadAsStringAsync().Result;
                }
                else
                {
                    //return ducCustomerWishList.ToString();
                }

                return r;
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in wishlist API {0}", ex.Message));
            }

        }


        [HttpPost("GetAgeGroup")]
        [ActionName(nameof(GetAgeGroup))]
        public async Task<ResultObject> GetAgeGroup([FromBody] Environment environment)
        {
            var r = new ResultObject();
            var baseAPIUrl = await crmHelper.RetrieveEnvironmentValue(environment.EnvironmentValue, "diyar_GetAgeGroup", log);
            try
            {
                var response = new HttpResponseMessage();
                response = await crmHelper.RetrieveMultiple(baseAPIUrl, environment.EnvironmentValue, log);
                if (response != null)
                {
                    r.code = Convert.ToInt16(response.StatusCode);
                    r.message = "response recieved";
                    r.data = response.Content.ReadAsStringAsync().Result;
                }
                else
                {
                    //return ducCustomerWishList.ToString();
                }

                return r;
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in wishlist API {0}", ex.Message));
            }

        }


        [HttpPost("GetBrandsList")]
        [ActionName(nameof(GetBrandsList))]
        public async Task<ResultObject> GetBrandsList([FromBody] Environment environment)
        {
            var r = new ResultObject();
            var baseAPIUrl = await crmHelper.RetrieveEnvironmentValue(environment.EnvironmentValue, "diyar_GetBrandsList", log);

            try
            {
                var response = new HttpResponseMessage();
                response = await crmHelper.RetrieveMultiple(baseAPIUrl, environment.EnvironmentValue, log);
                if (response != null)
                {
                    r.code = Convert.ToInt16(response.StatusCode);
                    r.message = "response recieved";
                    r.data = response.Content.ReadAsStringAsync().Result;
                }
                else
                {
                    //return ducCustomerWishList.ToString();
                }

                return r;
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in wishlist API {0}", ex.Message));
            }

        }

        [HttpPost("GetFavColorsList")]
        [ActionName(nameof(GetFavColorsList))]
        public async Task<ResultObject> GetFavColorsList([FromBody] Environment environment)
        {
            var r = new ResultObject();
            var baseAPIUrl = await crmHelper.RetrieveEnvironmentValue(environment.EnvironmentValue, "diyar_GetFavColorsList", log);

            try
            {
                var response = new HttpResponseMessage();
                response = await crmHelper.RetrieveMultiple(baseAPIUrl, environment.EnvironmentValue, log);
                if (response != null)
                {
                    r.code = Convert.ToInt16(response.StatusCode);
                    r.message = "response recieved";
                    r.data = response.Content.ReadAsStringAsync().Result;
                }
                else
                {
                    //return ducCustomerWishList.ToString();
                }

                return r;
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in wishlist API {0}", ex.Message));
            }

        }

        [HttpPost("GetHobbiesList")]
        [ActionName(nameof(GetHobbiesList))]
        public async Task<ResultObject> GetHobbiesList([FromBody] Environment environment)
        {
            var r = new ResultObject();
            var baseAPIUrl = await crmHelper.RetrieveEnvironmentValue(environment.EnvironmentValue, "diyar_GetHobbiesList", log);

            try
            {
                var response = new HttpResponseMessage();
                response = await crmHelper.RetrieveMultiple(baseAPIUrl, environment.EnvironmentValue, log);
                if (response != null)
                {
                    r.code = Convert.ToInt16(response.StatusCode);
                    r.message = "response recieved";
                    r.data = response.Content.ReadAsStringAsync().Result;
                }
                else
                {
                    //return ducCustomerWishList.ToString();
                }

                return r;
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in wishlist API {0}", ex.Message));
            }

        }


        [HttpPost("GetCaseTypeList")]
        [ActionName(nameof(GetCaseTypeList))]
        public async Task<ResultObject> GetCaseTypeList([FromBody] Environment environment)
        {
            var r = new ResultObject();
            var baseAPIUrl = await crmHelper.RetrieveEnvironmentValue(environment.EnvironmentValue, "diyar_GetCaseTypeList", log);

            try
            {
                var response = new HttpResponseMessage();
                response = await crmHelper.RetrieveMultiple(baseAPIUrl, environment.EnvironmentValue, log);
                if (response != null)
                {
                    r.code = Convert.ToInt16(response.StatusCode);
                    r.message = "response recieved";
                    r.data = response.Content.ReadAsStringAsync().Result;
                }
                else
                {
                    //return ducCustomerWishList.ToString();
                }

                return r;
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in wishlist API {0}", ex.Message));
            }

        }


        [HttpPost("GetProfessionOfCustomerList")]
        [ActionName(nameof(GetProfessionOfCustomerList))]
        public async Task<ResultObject> GetProfessionOfCustomerList([FromBody] Environment environment)
        {
            var r = new ResultObject();
            var baseAPIUrl = await crmHelper.RetrieveEnvironmentValue(environment.EnvironmentValue, "diyar_GetProfessionOfCustomerList", log);

            try
            {
                var response = new HttpResponseMessage();
                response = await crmHelper.RetrieveMultiple(baseAPIUrl, environment.EnvironmentValue, log);
                if (response != null)
                {
                    r.code = Convert.ToInt16(response.StatusCode);
                    r.message = "response recieved";
                    r.data = response.Content.ReadAsStringAsync().Result;
                }
                else
                {
                    //return ducCustomerWishList.ToString();
                }

                return r;
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in wishlist API {0}", ex.Message));
            }

        }


        [HttpPost("GetGenderCode")]
        [ActionName(nameof(GetGenderCode))]
        public async Task<ResultObject> GetGenderCode([FromBody] Environment environment)
        {
            var r = new ResultObject();
            var baseAPIUrl = await crmHelper.RetrieveEnvironmentValue(environment.EnvironmentValue, "diyar_GetGenderCode", log);

            try
            {
                var response = new HttpResponseMessage();
                response = await crmHelper.RetrieveMultiple(baseAPIUrl, environment.EnvironmentValue, log);
                if (response != null)
                {
                    r.code = Convert.ToInt16(response.StatusCode);
                    r.message = "response recieved";
                    r.data = response.Content.ReadAsStringAsync().Result;
                }
                else
                {
                    //return ducCustomerWishList.ToString();
                }

                return r;
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in wishlist API {0}", ex.Message));
            }

        }

        [HttpPost("GetAreaList")]
        [ActionName(nameof(GetAreaList))]
        public async Task<ResultObject> GetAreaList([FromBody] Environment environment)
        {
            var r = new ResultObject();
            var baseAPIUrl = await crmHelper.RetrieveEnvironmentValue(environment.EnvironmentValue, "diyar_GetAreaList", log);

            try
            {
                var response = new HttpResponseMessage();
                response = await crmHelper.RetrieveMultiple(baseAPIUrl, environment.EnvironmentValue, log);
                if (response != null)
                {
                    r.code = Convert.ToInt16(response.StatusCode);
                    r.message = "response recieved";
                    r.data = response.Content.ReadAsStringAsync().Result;
                }
                else
                {
                    //return ducCustomerWishList.ToString();
                }

                return r;
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in wishlist API {0}", ex.Message));
            }

        }


        [HttpPost("GetHowDidYouHearAboutUsList")]
        [ActionName(nameof(GetHowDidYouHearAboutUsList))]
        public async Task<ResultObject> GetHowDidYouHearAboutUsList([FromBody] Environment environment)
        {
            var r = new ResultObject();
            var baseAPIUrl = await crmHelper.RetrieveEnvironmentValue(environment.EnvironmentValue, "diyar_GetHowDidYouHearAboutUsList", log);

            try
            {
                var response = new HttpResponseMessage();
                response = await crmHelper.RetrieveMultiple(baseAPIUrl, environment.EnvironmentValue, log);
                if (response != null)
                {
                    r.code = Convert.ToInt16(response.StatusCode);
                    r.message = "response recieved";
                    r.data = response.Content.ReadAsStringAsync().Result;
                }
                else
                {
                    //return ducCustomerWishList.ToString();
                }

                return r;
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in wishlist API {0}", ex.Message));
            }

        }


        [HttpPost("GetNotificationsofCasesbyAssociatedContact")]
        [ActionName(nameof(GetNotificationsofCasesbyAssociatedContact))]
        public async Task<ResultObject> GetNotificationsofCasesbyAssociatedContact([FromBody] AssociatedContact contact)
        {
            var r = new ResultObject();
            var baseAPIUrl = await crmHelper.RetrieveEnvironmentValue(contact.EnvironmentValue, "diyar_GetNotificationsofCasesbyAssociatedContact", log);

            try
            {
                var response = new HttpResponseMessage();
                var RegistrationAPI = baseAPIUrl.Replace("{AC.ID}", contact.regardingobjectid_incident_customerid_value);
                response = await crmHelper.RetrieveMultiple(RegistrationAPI, contact.EnvironmentValue, log);
                if (response != null)
                {
                    r.code = Convert.ToInt16(response.StatusCode);
                    r.message = "response recieved";
                    r.data = response.Content.ReadAsStringAsync().Result;
                }
                else
                {
                    //return ducCustomerWishList.ToString();
                }

                return r;
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in wishlist API {0}", ex.Message));
            }

        }


        [HttpPost("GetCaseStatusCodes")]
        [ActionName(nameof(GetCaseStatusCodes))]
        public async Task<ResultObject> GetCaseStatusCodes([FromBody] Environment environment)
        {
            var r = new ResultObject();
            var baseAPIUrl = await crmHelper.RetrieveEnvironmentValue(environment.EnvironmentValue, "diyar_GetCaseStatusCodes", log);

            try
            {
                var response = new HttpResponseMessage();
                response = await crmHelper.RetrieveMultiple(baseAPIUrl, environment.EnvironmentValue, log);
                if (response != null)
                {
                    r.code = Convert.ToInt16(response.StatusCode);
                    r.message = "response recieved";
                    r.data = response.Content.ReadAsStringAsync().Result;
                }
                else
                {
                    //return ducCustomerWishList.ToString();
                }

                return r;
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format(CultureInfo.InvariantCulture, $"Exception thrown in wishlist API {0}", ex.Message));
            }

        }
    }
}
